package com.amha.player.data

import java.nio.ByteBuffer
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction

data class Cue(val startMs: Long, val endMs: Long, val text: String)

/** Parses SRT, WebVTT and ASS/SSA into plain-text cues. Styling tags are stripped. */
object SubtitleParser {

    /** Display name to charset name. null means auto-detect. */
    val ENCODINGS: List<Pair<String, String?>> = listOf(
        "Auto" to null,
        "UTF-8" to "UTF-8",
        "UTF-16" to "UTF-16",
        "Latin (Windows-1252)" to "windows-1252",
        "Central Europe (1250)" to "windows-1250",
        "Cyrillic (1251)" to "windows-1251",
        "Greek (1253)" to "windows-1253",
        "Turkish (1254)" to "windows-1254",
        "Hebrew (1255)" to "windows-1255",
        "Arabic (1256)" to "windows-1256",
        "Chinese (GBK)" to "GBK",
        "Chinese (Big5)" to "Big5",
        "Japanese (Shift_JIS)" to "Shift_JIS",
        "Korean (EUC-KR)" to "EUC-KR"
    )

    fun decode(b: ByteArray, charsetName: String?): String {
        val text = when {
            charsetName != null -> String(b, Charset.forName(charsetName))
            b.size >= 3 && b[0] == 0xEF.toByte() && b[1] == 0xBB.toByte() && b[2] == 0xBF.toByte() ->
                String(b, Charsets.UTF_8)
            b.size >= 2 && b[0] == 0xFF.toByte() && b[1] == 0xFE.toByte() -> String(b, Charsets.UTF_16LE)
            b.size >= 2 && b[0] == 0xFE.toByte() && b[1] == 0xFF.toByte() -> String(b, Charsets.UTF_16BE)
            else -> try {
                Charsets.UTF_8.newDecoder()
                    .onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT)
                    .decode(ByteBuffer.wrap(b)).toString()
            } catch (_: Exception) {
                String(b, Charset.forName("windows-1252"))
            }
        }
        return text.removePrefix("﻿")
    }

    fun parse(raw: String): List<Cue> {
        val text = raw.replace("\r\n", "\n").replace('\r', '\n')
        val cues = when {
            text.contains("[Script Info]", true) || text.contains("\nDialogue:") || text.startsWith("Dialogue:") ->
                parseAss(text)
            else -> parseSrtOrVtt(text)
        }
        return cues.filter { it.text.isNotBlank() && it.endMs > it.startMs }.sortedBy { it.startMs }
    }

    // ---- SRT / VTT ----------------------------------------------------------------------------

    private const val T = """(?:(\d+):)?(\d{1,2}):(\d{2})[,.](\d{1,3})"""
    private val TIME_LINE = Regex("""($T)\s*-->\s*($T)""")
    private val TAGS = Regex("""<[^>]*>|\{\\[^}]*\}""")

    private fun parseSrtOrVtt(text: String): List<Cue> {
        val out = mutableListOf<Cue>()
        for (block in text.split(Regex("\n{2,}"))) {
            val lines = block.split('\n')
            val idx = lines.indexOfFirst { "-->" in it }
            if (idx < 0) continue
            val m = TIME_LINE.find(lines[idx]) ?: continue
            val g = m.groupValues
            // groups: 1 whole start, 2-5 start h,m,s,f ; 6 whole end, 7-10 end h,m,s,f
            val start = ms(g[2], g[3], g[4], g[5])
            val end = ms(g[7], g[8], g[9], g[10])
            val body = lines.drop(idx + 1).joinToString("\n") { TAGS.replace(it, "").trim() }.trim()
            if (body.isNotEmpty()) out += Cue(start, end, decodeEntities(body))
        }
        return out
    }

    private fun ms(h: String, m: String, s: String, f: String): Long =
        (h.toLongOrNull() ?: 0L) * 3_600_000L + m.toLong() * 60_000L + s.toLong() * 1000L +
            f.padEnd(3, '0').take(3).toLong()

    private fun decodeEntities(s: String) =
        s.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
            .replace("&nbsp;", " ").replace("&quot;", "\"")

    // ---- ASS / SSA ----------------------------------------------------------------------------

    private val ASS_TIME = Regex("""(\d+):(\d{2}):(\d{2})[.:](\d{1,3})""")
    private val ASS_BLOCK = Regex("""\{[^}]*\}""")

    private fun assTime(s: String): Long? {
        val m = ASS_TIME.find(s.trim()) ?: return null
        val frac = m.groupValues[4]
        // ASS uses centiseconds; treat 1-2 digits as centis, 3 as millis.
        val millis = if (frac.length >= 3) frac.take(3).toLong() else frac.padEnd(2, '0').toLong() * 10
        return m.groupValues[1].toLong() * 3_600_000L + m.groupValues[2].toLong() * 60_000L +
            m.groupValues[3].toLong() * 1000L + millis
    }

    private fun parseAss(text: String): List<Cue> {
        val out = mutableListOf<Cue>()
        var inEvents = false
        var startI = 1
        var endI = 2
        var textI = 9
        var fields = 10
        for (line in text.split('\n')) {
            val l = line.trim()
            if (l.startsWith("[")) {
                inEvents = l.equals("[Events]", true)
                continue
            }
            if (!inEvents) continue
            if (l.startsWith("Format:", true)) {
                val names = l.substringAfter(':').split(',').map { it.trim().lowercase() }
                fields = names.size
                startI = names.indexOf("start").takeIf { it >= 0 } ?: 1
                endI = names.indexOf("end").takeIf { it >= 0 } ?: 2
                textI = names.indexOf("text").takeIf { it >= 0 } ?: (names.size - 1)
            } else if (l.startsWith("Dialogue:", true)) {
                val parts = l.substringAfter(':').split(',', limit = fields)
                if (parts.size <= textI) continue
                val s = assTime(parts[startI]) ?: continue
                val e = assTime(parts[endI]) ?: continue
                val body = ASS_BLOCK.replace(parts[textI], "")
                    .replace("\\N", "\n").replace("\\n", "\n").replace("\\h", " ")
                    .trim()
                if (body.isNotEmpty()) out += Cue(s, e, body)
            }
        }
        return out
    }
}
