package com.amha.player.ui

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Link
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.amha.player.VideoActivity
import com.amha.player.data.LinkStore
import com.amha.player.data.LinkUtil
import com.amha.player.playback.PlayerHolder

internal fun openLink(ctx: Context, url: String) {
    val title = LinkUtil.titleFor(url)
    LinkStore.add(url, title)
    PlayerHolder.player.pause() // don't talk over the music
    ctx.startActivity(
        Intent(ctx, VideoActivity::class.java)
            .putExtra(VideoActivity.EXTRA_URI, url)
            .putExtra(VideoActivity.EXTRA_TITLE, title)
    )
}

/** Paste a link, play it, and see recent ones. */
@Composable
fun LinksPane() {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val accent = MaterialTheme.colorScheme.primary
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    var input by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) { LinkStore.init(ctx) }

    fun play(raw: String) {
        val url = LinkUtil.normalize(raw)
        if (url == null) {
            error = "That doesn't look like a link. Use http, https or rtsp."
            return
        }
        error = null
        openLink(ctx, url)
    }

    Column(Modifier.fillMaxSize()) {
        TextField(
            value = input,
            onValueChange = { input = it; error = null },
            singleLine = true,
            placeholder = { Text("Paste a video or audio link") },
            leadingIcon = { Icon(Icons.Filled.Link, null, tint = dim) },
            shape = RoundedCornerShape(14.dp),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
            keyboardActions = KeyboardActions(onGo = { play(input) }),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent
            ),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
        )
        error?.let {
            Text(it, color = Color(0xFFFF6B6B), fontSize = 12.sp, modifier = Modifier.padding(horizontal = 20.dp))
        }
        Row(
            Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                "Play", color = Color.Black,
                modifier = Modifier
                    .clip(RoundedCornerShape(24.dp))
                    .background(accent)
                    .clickable { play(input) }
                    .padding(horizontal = 26.dp, vertical = 10.dp)
            )
            Text(
                "Paste",
                modifier = Modifier
                    .clip(RoundedCornerShape(24.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .clickable {
                        val t = clipboard.getText()?.text.orEmpty().trim()
                        if (t.isNotEmpty()) { input = t; error = null }
                    }
                    .padding(horizontal = 22.dp, vertical = 10.dp)
            )
        }
        Text(
            "Works with direct links to video or audio files, HLS (.m3u8), DASH (.mpd) and rtsp. " +
                "SMB network shares are not supported yet.",
            color = dim, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 20.dp)
        )

        val links = LinkStore.links
        Row(
            Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("RECENT LINKS", fontSize = 11.sp, letterSpacing = 2.sp, color = dim, modifier = Modifier.weight(1f))
            if (links.isNotEmpty()) TextButton(onClick = { LinkStore.clear() }) { Text("Clear", color = dim, fontSize = 12.sp) }
        }
        if (links.isEmpty()) {
            Text("Links you play show up here.", color = dim, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
        }
        LazyColumn(Modifier.fillMaxSize()) {
            items(links, key = { it.url }) { l ->
                Row(
                    Modifier.fillMaxWidth().clickable { openLink(ctx, l.url) }
                        .padding(start = 20.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(l.title, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(l.url, fontSize = 11.sp, color = dim, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    IconButton(onClick = { LinkStore.remove(l.url) }) {
                        Icon(Icons.Filled.Close, "Remove", tint = dim, modifier = Modifier.size(20.dp))
                    }
                }
            }
        }
    }
}
