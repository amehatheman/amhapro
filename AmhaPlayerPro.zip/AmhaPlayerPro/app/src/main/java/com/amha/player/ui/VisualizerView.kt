package com.amha.player.ui

import android.content.Context
import android.media.audiofx.Visualizer
import android.os.PowerManager
import androidx.activity.ComponentActivity
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.amha.player.audio.VizConfig
import com.amha.player.audio.VizEngine
import com.amha.player.audio.VizPalette
import com.amha.player.audio.VizStyle
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Real-time visualizer driven by the actual audio output (android.media.audiofx.Visualizer).
 * Needs RECORD_AUDIO. Settings come from [VizSettings]. Capture runs only while the app is in
 * the foreground and music is playing; the draw loop sleeps once everything has faded out.
 */
@Composable
fun SpectrumVisualizer(
    audioSessionId: Int,
    isPlaying: Boolean,
    accent: Color,
    modifier: Modifier = Modifier,
    onLongPress: (() -> Unit)? = null
) {
    val ctx = LocalContext.current
    val cfg = VizSettings.config
    val cfgNow = rememberUpdatedState(cfg)
    val engine = remember { VizEngine() }
    var frame by remember { mutableLongStateOf(0L) }
    var started by remember { mutableStateOf(true) }
    val saver = remember(started) {
        try {
            (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isPowerSaveMode
        } catch (_: Throwable) {
            false
        }
    }

    // Only capture and draw while the app is visible.
    val act = ctx as? ComponentActivity
    DisposableEffect(act) {
        val o = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_START) started = true
            if (e == Lifecycle.Event.ON_STOP) started = false
        }
        act?.lifecycle?.addObserver(o)
        onDispose { act?.lifecycle?.removeObserver(o) }
    }

    LaunchedEffect(cfg.bars, cfg.range) { engine.clearTargets() }

    val needsWave = cfg.style == VizStyle.WAVE || cfg.style == VizStyle.RING
    DisposableEffect(audioSessionId, isPlaying, started, needsWave, saver) {
        var viz: Visualizer? = null
        if (audioSessionId != 0 && isPlaying && started) {
            try {
                viz = Visualizer(audioSessionId).apply {
                    captureSize = Visualizer.getCaptureSizeRange()[1].coerceAtMost(1024)
                    val rate = if (saver) Visualizer.getMaxCaptureRate() / 2 else Visualizer.getMaxCaptureRate()
                    setDataCaptureListener(
                        object : Visualizer.OnDataCaptureListener {
                            override fun onWaveFormDataCapture(v: Visualizer?, w: ByteArray?, r: Int) {
                                if (w != null) engine.onWave(w)
                            }

                            override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, r: Int) {
                                if (fft != null) engine.onFft(fft, cfgNow.value)
                            }
                        },
                        rate,
                        needsWave,
                        true
                    )
                    enabled = true
                }
            } catch (_: Throwable) {
                // No RECORD_AUDIO permission or the device refuses the effect: show nothing.
                viz = null
            }
        }
        onDispose {
            try {
                viz?.enabled = false
                viz?.release()
            } catch (_: Throwable) {
            }
        }
    }

    // Draw loop: runs while playing, then until the bars have fallen to nothing.
    LaunchedEffect(isPlaying, started, saver) {
        if (!started) return@LaunchedEffect
        var last = 0L
        val minGap = if (saver) 33_000_000L else 0L
        while (true) {
            val now = withFrameNanos { it }
            if (last == 0L) {
                last = now
                continue
            }
            if (now - last < minGap) continue
            val dt = ((now - last) / 1_000_000_000f).coerceIn(0.001f, 0.1f)
            last = now
            if (!isPlaying) engine.clearTargets()
            engine.step(dt, cfgNow.value)
            frame = now
            if (!isPlaying && engine.quiet) break
        }
    }

    Box(
        modifier = modifier.pointerInput(Unit) {
            detectTapGestures(
                onTap = {
                    val c = VizSettings.config
                    val next = VizStyle.entries[(c.style.ordinal + 1) % VizStyle.entries.size]
                    VizSettings.update(c.copy(style = next))
                },
                onLongPress = { onLongPress?.invoke() }
            )
        }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            @Suppress("UNUSED_VARIABLE") val tick = frame // reading it redraws every frame
            when (cfg.style) {
                VizStyle.BARS -> drawBars(engine, cfg, accent, mirrored = false)
                VizStyle.MIRROR -> drawBars(engine, cfg, accent, mirrored = true)
                VizStyle.RADIAL -> drawRadial(engine, cfg, accent)
                VizStyle.WAVE -> drawWave(engine, cfg, accent)
                VizStyle.FLOW -> drawFlow(engine, cfg, accent)
                VizStyle.RING -> drawRing(engine, cfg, accent)
                VizStyle.PULSE -> drawPulse(engine, cfg, accent)
                VizStyle.PARTICLES -> drawParticles(engine, cfg, accent)
            }
        }
    }
}

// ---------- colour helpers ----------

private fun paletteColors(p: VizPalette, accent: Color, alpha: Float): List<Color> {
    val base = if (p.stops.isEmpty()) listOf(accent, accent) else p.stops.map { Color(it) }
    return base.map { it.copy(alpha = it.alpha * alpha) }
}

private fun colorAt(colors: List<Color>, t: Float): Color {
    if (colors.size == 1) return colors[0]
    val x = t.coerceIn(0f, 1f) * (colors.size - 1)
    val i = x.toInt().coerceAtMost(colors.size - 2)
    return lerp(colors[i], colors[i + 1], x - i)
}

private fun glowAlpha(c: VizConfig) = c.glow * 0.35f * c.opacity

// ---------- drawing ----------

private fun DrawScope.drawBars(e: VizEngine, c: VizConfig, accent: Color, mirrored: Boolean) {
    val n = c.bars
    val colors = paletteColors(c.palette, accent, 1f)
    val slot = size.width / n
    val barW = slot * c.thickness
    val mid = size.height / 2f
    val maxH = size.height * c.height * (if (mirrored) 0.5f else 1f)
    val glow = glowAlpha(c)
    for (i in 0 until n) {
        val v = e.shown[i]
        val h = (v * maxH).coerceAtLeast(3f)
        val x = i * slot + (slot - barW) / 2f
        val col = colorAt(colors, i.toFloat() / max(1, n - 1)).copy(alpha = c.opacity * (0.45f + 0.55f * v))
        val top = if (mirrored) mid - h else size.height - h
        val hh = if (mirrored) h * 2f else h
        if (glow > 0.02f && v > 0.05f) {
            val pad = barW * (0.4f + c.glow)
            drawRoundRect(
                col.copy(alpha = glow * v),
                Offset(x - pad, top - pad), Size(barW + pad * 2, hh + pad * 2),
                CornerRadius(barW / 2 + pad)
            )
        }
        drawRoundRect(col, Offset(x, top), Size(barW, hh), CornerRadius(barW / 2))
    }
}

private fun DrawScope.drawRadial(e: VizEngine, c: VizConfig, accent: Color) {
    val n = c.bars
    val colors = paletteColors(c.palette, accent, 1f)
    val ctr = Offset(size.width / 2, size.height / 2)
    val m = min(size.width, size.height)
    val base = m * 0.22f
    val maxLen = m * 0.26f * c.height
    val bass = e.bass
    drawCircle(
        colorAt(colors, 0.1f).copy(alpha = (0.08f + 0.25f * bass) * c.opacity),
        radius = base * (1f + 0.15f * bass), center = ctr
    )
    val w = (2f * PI.toFloat() * base / n) * c.thickness
    for (i in 0 until n) {
        val a = (i.toFloat() / n) * 2f * PI.toFloat() - PI.toFloat() / 2
        val v = e.shown[i]
        val len = 4f + v * maxLen
        val s = Offset(ctr.x + cos(a) * base, ctr.y + sin(a) * base)
        val t = Offset(ctr.x + cos(a) * (base + len), ctr.y + sin(a) * (base + len))
        val col = colorAt(colors, i.toFloat() / n).copy(alpha = c.opacity * (0.45f + 0.55f * v))
        if (c.glow > 0.02f && v > 0.05f) {
            drawLine(col.copy(alpha = glowAlpha(c) * v), s, t, strokeWidth = w * (1.8f + c.glow * 2f), cap = StrokeCap.Round)
        }
        drawLine(col, s, t, strokeWidth = w, cap = StrokeCap.Round)
    }
    drawCircle(colorAt(colors, 0.5f).copy(alpha = 0.5f * c.opacity), radius = base, center = ctr, style = Stroke(width = 2f))
}

private fun DrawScope.drawWave(e: VizEngine, c: VizConfig, accent: Color) {
    val n = VizEngine.WAVE_POINTS
    val colors = paletteColors(c.palette, accent, c.opacity)
    val mid = size.height / 2f
    val amp = size.height * 0.45f * c.height * min(c.sensitivity, 2f)
    val path = Path()
    for (i in 0 until n) {
        val x = size.width * i / (n - 1)
        val y = mid - e.waveShown[i].coerceIn(-1f, 1f) * amp
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    val brush = Brush.horizontalGradient(colors, 0f, size.width)
    val w = 2f + 6f * c.thickness
    if (c.glow > 0.02f) {
        drawPath(path, brush, alpha = glowAlpha(c) / max(0.01f, c.opacity), style = Stroke(w * (2f + c.glow * 3f), cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
    drawPath(path, brush, style = Stroke(w, cap = StrokeCap.Round, join = StrokeJoin.Round))
}

private fun DrawScope.drawFlow(e: VizEngine, c: VizConfig, accent: Color) {
    val n = c.bars
    val colors = paletteColors(c.palette, accent, c.opacity)
    val maxH = size.height * c.height
    val step = size.width / (n - 1)
    fun y(i: Int) = size.height - (e.shown[i] * maxH).coerceAtLeast(2f)
    val line = Path()
    line.moveTo(0f, y(0))
    for (i in 1 until n) {
        val cx = (i - 1) * step + step / 2f
        val cy = (y(i - 1) + y(i)) / 2f
        line.quadraticBezierTo((i - 1) * step, y(i - 1), cx, cy)
    }
    line.lineTo(size.width, y(n - 1))
    val area = Path().apply {
        addPath(line)
        lineTo(size.width, size.height)
        lineTo(0f, size.height)
        close()
    }
    val fill = Brush.verticalGradient(
        listOf(colorAt(colors, 0.5f).copy(alpha = 0.55f * c.opacity), Color.Transparent),
        startY = size.height - maxH, endY = size.height
    )
    drawPath(area, fill)
    val brush = Brush.horizontalGradient(colors, 0f, size.width)
    val w = 2f + 5f * c.thickness
    if (c.glow > 0.02f) {
        drawPath(line, brush, alpha = glowAlpha(c) / max(0.01f, c.opacity), style = Stroke(w * (2f + c.glow * 3f), cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
    drawPath(line, brush, style = Stroke(w, cap = StrokeCap.Round, join = StrokeJoin.Round))
}

private fun DrawScope.drawRing(e: VizEngine, c: VizConfig, accent: Color) {
    val n = VizEngine.WAVE_POINTS
    val colors = paletteColors(c.palette, accent, c.opacity)
    val ctr = Offset(size.width / 2, size.height / 2)
    val m = min(size.width, size.height)
    val base = m * 0.25f * (1f + 0.12f * e.bass)
    val amp = m * 0.2f * c.height * min(c.sensitivity, 2f)
    val path = Path()
    for (i in 0..n) {
        val k = i % n
        val a = (k.toFloat() / n) * 2f * PI.toFloat() - PI.toFloat() / 2
        val r = base + e.waveShown[k].coerceIn(-1f, 1f) * amp
        val x = ctr.x + cos(a) * r
        val y = ctr.y + sin(a) * r
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    val sweep = Brush.sweepGradient(colors + colors.first(), ctr)
    val w = 2f + 6f * c.thickness
    if (c.glow > 0.02f) {
        drawPath(path, sweep, alpha = glowAlpha(c) / max(0.01f, c.opacity), style = Stroke(w * (2f + c.glow * 3f), join = StrokeJoin.Round))
    }
    drawPath(path, sweep, style = Stroke(w, join = StrokeJoin.Round))
}

private fun DrawScope.drawPulse(e: VizEngine, c: VizConfig, accent: Color) {
    val colors = paletteColors(c.palette, accent, 1f)
    val ctr = Offset(size.width / 2, size.height / 2)
    val m = min(size.width, size.height)
    val maxR = m * 0.45f * c.height
    val levels = floatArrayOf(e.bass, e.mid, e.treble)
    val scales = floatArrayOf(1f, 0.68f, 0.4f)
    val w = 2f + 8f * c.thickness
    // Soft glowing core that breathes with the bass.
    val coreR = maxR * (0.5f + 0.5f * e.bass)
    drawCircle(
        Brush.radialGradient(
            listOf(colorAt(colors, 0f).copy(alpha = (0.15f + 0.55f * e.bass) * c.opacity * (0.4f + c.glow)), Color.Transparent),
            ctr, coreR
        ),
        radius = coreR, center = ctr
    )
    for (i in 0..2) {
        val r = maxR * scales[i] * (0.8f + 0.35f * levels[i])
        val col = colorAt(colors, i / 2f).copy(alpha = c.opacity * (0.35f + 0.65f * levels[i].coerceAtMost(1f)))
        if (c.glow > 0.02f) {
            drawCircle(col.copy(alpha = glowAlpha(c) * (0.3f + levels[i])), radius = r, center = ctr, style = Stroke(w * (2f + c.glow * 3f)))
        }
        drawCircle(col, radius = r, center = ctr, style = Stroke(w))
    }
}

private fun DrawScope.drawParticles(e: VizEngine, c: VizConfig, accent: Color) {
    val colors = paletteColors(c.palette, accent, 1f)
    val ctr = Offset(size.width / 2, size.height / 2)
    val m = min(size.width, size.height)
    val p = e.particles
    drawCircle(
        Brush.radialGradient(
            listOf(colorAt(colors, 0.3f).copy(alpha = (0.1f + 0.5f * e.bass) * c.opacity), Color.Transparent),
            ctr, m * (0.12f + 0.1f * e.bass)
        ),
        radius = m * (0.12f + 0.1f * e.bass), center = ctr
    )
    for (i in 0 until p.count) {
        val life = (p.life[i] / p.maxLife[i]).coerceIn(0f, 1f)
        val col = colorAt(colors, p.t[i]).copy(alpha = c.opacity * life)
        val r = p.size[i] * m * (0.6f + 1.6f * c.thickness) * (0.6f + 0.4f * life)
        val pos = Offset(p.x[i] * size.width, p.y[i] * size.height)
        if (c.glow > 0.02f) drawCircle(col.copy(alpha = glowAlpha(c) * life), radius = r * (2f + 2f * c.glow), center = pos)
        drawCircle(col, radius = r, center = pos)
    }
}
