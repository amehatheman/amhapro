package com.amha.player.playback

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.amha.player.audio.EqualizerEngine
import com.amha.player.data.LyricsStore
import com.amha.player.data.PlaylistStore
import com.amha.player.data.Track

/** Single music player shared by the UI and the media session service. */
object PlayerHolder {
    lateinit var player: ExoPlayer
        private set
    private lateinit var appContext: Context

    fun init(ctx: Context) {
        if (::player.isInitialized) return
        appContext = ctx.applicationContext
        player = ExoPlayer.Builder(appContext)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(C.USAGE_MEDIA)
                    .build(),
                /* handleAudioFocus = */ true
            )
            .setHandleAudioBecomingNoisy(true)
            .build()
        EqualizerEngine.init(appContext, player)
        com.amha.player.audio.TrackFader.init(appContext, player)
        PlaylistStore.init(appContext)
        LyricsStore.init(appContext)
        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                mediaItem?.mediaId?.toLongOrNull()?.let { PlaylistStore.recordPlayed(it) }
            }
        })
    }

    private fun Track.toItem(): MediaItem =
        MediaItem.Builder()
            .setMediaId(id.toString())
            .setUri(uri)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(title)
                    .setArtist(artist)
                    .setAlbumTitle(album)
                    .setArtworkUri(artUri)
                    .setExtras(Bundle().apply { putString("path", path) })
                    .build()
            )
            .build()

    private fun startService() {
        ContextCompat.startForegroundService(
            appContext, Intent(appContext, PlaybackService::class.java)
        )
    }

    fun playQueue(tracks: List<Track>, startIndex: Int) {
        player.setMediaItems(tracks.map { it.toItem() }, startIndex, 0L)
        player.prepare()
        player.play()
        startService()
    }

    /** Inserts right after the song that is playing. Starts playback if the queue is empty. */
    fun playNext(t: Track) {
        if (player.mediaItemCount == 0) { playQueue(listOf(t), 0); return }
        player.addMediaItem(player.currentMediaItemIndex + 1, t.toItem())
    }

    /** Adds to the end of the queue. Starts playback if the queue is empty. */
    fun addToQueue(t: Track) {
        if (player.mediaItemCount == 0) { playQueue(listOf(t), 0); return }
        player.addMediaItem(t.toItem())
    }
}
