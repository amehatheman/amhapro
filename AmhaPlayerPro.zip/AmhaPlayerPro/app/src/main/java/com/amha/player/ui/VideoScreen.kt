package com.amha.player.ui

import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.geometry.Offset as GeoOffset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.SubtitleView
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

private val SPEEDS = listOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f, 3f, 4f)

private data class AspectOption(val label: String, val mode: Int)

private val ASPECTS = listOf(
    AspectOption("Fit", AspectRatioFrameLayout.RESIZE_MODE_FIT),
    AspectOption("Crop to fill", AspectRatioFrameLayout.RESIZE_MODE_ZOOM),
    AspectOption("Stretch", AspectRatioFrameLayout.RESIZE_MODE_FILL)
)

private data class OrientOption(val label: String, val value: Int)

private val ORIENTS = listOf(
    OrientOption("Auto rotate", ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED),
    OrientOption("Landscape", ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE),
    OrientOption("Portrait", ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT)
)

private fun speedLabel(s: Float) = (if (s % 1f == 0f) s.toInt().toString() else s.toString()) + "x"

private fun initialBrightness(a: Activity): Float {
    val w = a.window.attributes.screenBrightness
    if (w >= 0f) return w
    return try {
        Settings.System.getInt(a.contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
    } catch (_: Exception) {
        0.5f
    }
}

@Composable
fun VideoScreen(
    activity: Activity,
    player: ExoPlayer,
    title: String,
    inPip: Boolean,
    onBack: () -> Unit,
    onPip: () -> Unit
) {
    val accent = MaterialTheme.colorScheme.primary
    val scope = rememberCoroutineScope()

    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    var playing by remember { mutableStateOf(player.isPlaying) }
    var controls by remember { mutableStateOf(true) }
    var locked by remember { mutableStateOf(false) }
    var interaction by remember { mutableIntStateOf(0) }
    var hud by remember { mutableStateOf<String?>(null) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var aspectIdx by remember { mutableIntStateOf(0) }
    var orientIdx by remember { mutableIntStateOf(0) }
    var speed by remember { mutableFloatStateOf(1f) }
    var speedMenu by remember { mutableStateOf(false) }
    var seekPreview by remember { mutableStateOf<Long?>(null) }
    var sliderDrag by remember { mutableStateOf<Float?>(null) }

    // ---- streaming state ----
    var buffering by remember { mutableStateOf(false) }
    var playError by remember { mutableStateOf<String?>(null) }
    var retries by remember { mutableIntStateOf(0) }

    // ---- subtitles & tracks ----
    val subs = remember { SubtitleController() }
    var panel by remember { mutableStateOf(false) }
    var subText by remember { mutableStateOf<String?>(null) }
    var textOptions by remember { mutableStateOf<List<TrackOption>>(emptyList()) }
    var audioOptions by remember { mutableStateOf<List<TrackOption>>(emptyList()) }
    remember { SubtitleStyleStore.init(activity); 0 }

    fun trackLabel(g: Tracks.Group, index: Int, audio: Boolean): String {
        val f = g.getTrackFormat(0)
        val lang = f.language?.takeIf { it != "und" }
            ?.let { Locale.forLanguageTag(it).displayLanguage }?.takeIf { it.isNotBlank() }
        val base = f.label ?: lang ?: "Track ${index + 1}"
        return if (audio && f.channelCount > 0) "$base · ${f.channelCount}ch" else base
    }

    fun refreshTracks(t: Tracks) {
        val texts = t.groups.filter { it.type == C.TRACK_TYPE_TEXT && it.isSupported }
        val audios = t.groups.filter { it.type == C.TRACK_TYPE_AUDIO && it.isSupported }
        textOptions = texts.mapIndexed { i, g -> TrackOption(trackLabel(g, i, false), g.isSelected, g.mediaTrackGroup) }
        audioOptions = audios.mapIndexed { i, g -> TrackOption(trackLabel(g, i, true), g.isSelected, g.mediaTrackGroup) }
        if (subs.source != SubSource.EXTERNAL) {
            subs.source = if (texts.any { it.isSelected }) SubSource.EMBEDDED else SubSource.OFF
        }
    }

    fun selectOff() {
        subs.source = SubSource.OFF
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
    }

    fun selectText(o: TrackOption) {
        subs.source = SubSource.EMBEDDED
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            .setOverrideForType(TrackSelectionOverride(o.group, 0)).build()
    }

    fun selectAudio(o: TrackOption) {
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setOverrideForType(TrackSelectionOverride(o.group, 0)).build()
    }

    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val loaded = withContext(Dispatchers.IO) {
                try {
                    val name = activity.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
                        ?.use { c -> if (c.moveToFirst()) c.getString(0) else null } ?: "subtitle"
                    val bytes = activity.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    if (bytes != null && bytes.size < 8_000_000) name to bytes else null
                } catch (_: Throwable) { null }
            }
            if (loaded != null) {
                subs.load(loaded.first, loaded.second)
                if (subs.source == SubSource.EXTERNAL) {
                    // Hide the video's own subtitles so the two don't overlap.
                    player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
                    hud = "Subtitles loaded"
                }
            } else hud = "Could not read that file"
        }
    }

    val am = remember { activity.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVol = remember { am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var bright by remember { mutableFloatStateOf(initialBrightness(activity)) }
    var vol by remember { mutableFloatStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVol) }

    // Plain holders so gesture closures never see stale copies.
    val seekBase = remember { longArrayOf(0L) }
    val seekDx = remember { floatArrayOf(0f) }

    fun setBright(v: Float) {
        bright = v.coerceIn(0.02f, 1f)
        val lp = activity.window.attributes
        lp.screenBrightness = bright
        activity.window.attributes = lp
    }

    fun setVol(v: Float) {
        vol = v.coerceIn(0f, 1f)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, (vol * maxVol).roundToInt(), 0)
    }

    fun touch() { interaction++ }

    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onPlaybackStateChanged(state: Int) {
                buffering = state == Player.STATE_BUFFERING
                if (state == Player.STATE_READY) { playError = null; retries = 0 }
            }
            override fun onPlayerError(error: PlaybackException) {
                if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    player.seekToDefaultPosition()
                    player.prepare()
                    return
                }
                val dropped = error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED ||
                    error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT
                if (dropped && retries < 3) {
                    retries++
                    hud = "Reconnecting ($retries/3)…"
                    scope.launch {
                        delay(2000L * retries)
                        player.prepare()
                    }
                } else {
                    playError = friendlyError(error)
                }
            }
            override fun onVideoSizeChanged(videoSize: VideoSize) {
                // Wide video: open in landscape once, like MX Player. User can change it after.
                if (orientIdx == 0 && videoSize.width > videoSize.height) {
                    orientIdx = 1
                    activity.requestedOrientation = ORIENTS[1].value
                }
            }
        }
        val tl = object : Player.Listener {
            override fun onTracksChanged(tracks: Tracks) { refreshTracks(tracks) }
        }
        player.addListener(l)
        player.addListener(tl)
        refreshTracks(player.currentTracks)
        onDispose { player.removeListener(l); player.removeListener(tl) }
    }

    LaunchedEffect(player) {
        while (true) {
            val t = if (subs.source == SubSource.EXTERNAL) subs.textAt(player.currentPosition) else null
            if (t != subText) subText = t
            delay(100)
        }
    }

    LaunchedEffect(player) {
        while (true) {
            pos = player.currentPosition
            dur = player.duration.coerceAtLeast(0L)
            delay(250)
        }
    }

    LaunchedEffect(controls, interaction, playing, locked) {
        if (controls && playing) {
            delay(3500)
            controls = false
        }
    }

    LaunchedEffect(hud) {
        if (hud != null) {
            delay(900)
            hud = null
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {

        // ---- video surface -------------------------------------------------------------------
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer { scaleX = zoom; scaleY = zoom }
        ) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        useController = false
                        this.player = player
                        resizeMode = ASPECTS[aspectIdx].mode
                    }
                },
                update = { pv ->
                    pv.resizeMode = ASPECTS[aspectIdx].mode
                    pv.subtitleView?.apply {
                        setApplyEmbeddedStyles(false)
                        setApplyEmbeddedFontSizes(false)
                        setFractionalTextSize(SubtitleView.DEFAULT_TEXT_SIZE_FRACTION * SubtitleStyleStore.sizeSp / 20f)
                        setBottomPaddingFraction(SubtitleStyleStore.bottomPct / 100f + 0.02f)
                        val fg = SubtitleStyleStore.colors[SubtitleStyleStore.colorIdx].second.toArgb()
                        val box = SubtitleStyleStore.bgIdx == 1
                        setStyle(
                            CaptionStyleCompat(
                                fg,
                                if (box) android.graphics.Color.argb(166, 0, 0, 0) else android.graphics.Color.TRANSPARENT,
                                android.graphics.Color.TRANSPARENT,
                                when (SubtitleStyleStore.bgIdx) {
                                    0 -> CaptionStyleCompat.EDGE_TYPE_DROP_SHADOW
                                    else -> CaptionStyleCompat.EDGE_TYPE_NONE
                                },
                                android.graphics.Color.BLACK,
                                null
                            )
                        )
                    }
                }
            )
        }

        // ---- gesture layer -------------------------------------------------------------------
        val gestureModifier =
            if (locked || inPip) {
                Modifier.pointerInput(locked) {
                    detectTapGestures(onTap = { if (!inPip) { controls = !controls; touch() } })
                }
            } else {
                Modifier
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onTap = { controls = !controls; touch() },
                            onDoubleTap = { off ->
                                val third = size.width / 3f
                                when {
                                    off.x < third -> {
                                        val skip = GesturePrefs.skipMs(activity)
                                        player.seekTo((player.currentPosition - skip).coerceAtLeast(0))
                                        hud = "« ${skip / 1000}s"
                                    }
                                    off.x > 2 * third -> {
                                        player.seekTo(
                                            (player.currentPosition + GesturePrefs.skipMs(activity))
                                                .let { p -> if (player.duration > 0) p.coerceAtMost(player.duration) else p }
                                        )
                                        hud = "${GesturePrefs.skipMs(activity) / 1000}s »"
                                    }
                                    else -> if (player.isPlaying) player.pause() else player.play()
                                }
                            },
                            onPress = {
                                // Hold to speed up to 2x; release restores.
                                val job = scope.launch {
                                    delay(450)
                                    val hs = GesturePrefs.holdSpeed(activity)
                                    player.setPlaybackSpeed(hs)
                                    hud = speedLabel(hs) + " speed"
                                }
                                tryAwaitRelease()
                                job.cancel()
                                player.setPlaybackSpeed(speed)
                            }
                        )
                    }
                    .pointerInput(Unit) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            val startX = down.position.x
                            var mode = 0 // 0 undecided, 1 vertical, 2 horizontal, 3 pinch
                            var total = Offset.Zero
                            do {
                                val event = awaitPointerEvent()
                                val pressed = event.changes.count { it.pressed }
                                if (pressed >= 2) {
                                    mode = 3
                                    val z = event.calculateZoom()
                                    if (z != 1f) {
                                        zoom = (zoom * z).coerceIn(1f, 4f)
                                        hud = "Zoom ${"%.1f".format(zoom)}x"
                                    }
                                    event.changes.forEach { it.consume() }
                                } else if (mode != 3) {
                                    val change = event.changes.firstOrNull() ?: break
                                    val d = change.positionChange()
                                    total += d
                                    if (mode == 0 && total.getDistance() > viewConfiguration.touchSlop) {
                                        mode = if (abs(total.y) > abs(total.x)) 1 else 2
                                    }
                                    if (mode == 1) {
                                        val frac = -d.y / size.height * 1.3f * GesturePrefs.sensitivity(activity)
                                        if (startX < size.width / 2f) {
                                            setBright(bright + frac)
                                            hud = "Brightness ${(bright * 100).roundToInt()}%"
                                        } else {
                                            setVol(vol + frac)
                                            hud = "Volume ${(vol * 100).roundToInt()}%"
                                        }
                                        change.consume()
                                    } else if (mode == 2) {
                                        if (seekPreview == null) {
                                            seekBase[0] = player.currentPosition
                                            seekDx[0] = 0f
                                        }
                                        seekDx[0] += d.x
                                        val d0 = player.duration.coerceAtLeast(0L)
                                        val target = (seekBase[0] + (seekDx[0] * 80f * GesturePrefs.sensitivity(activity)).toLong())
                                            .coerceIn(0L, d0)
                                        seekPreview = target
                                        val delta = (target - seekBase[0]) / 1000
                                        hud = (if (delta >= 0) "+" else "-") + formatTime(abs(delta) * 1000) +
                                            "\n" + formatTime(target)
                                        change.consume()
                                    }
                                }
                            } while (event.changes.any { it.pressed })

                            seekPreview?.let { player.seekTo(it) }
                            seekPreview = null
                        }
                    }
            }
        Box(Modifier.fillMaxSize().then(gestureModifier))

        // ---- loaded-file subtitles ----------------------------------------------------------
        subText?.let { text ->
            val style = SubtitleStyleStore
            Box(
                Modifier.fillMaxSize().padding(horizontal = 28.dp),
                contentAlignment = Alignment.BottomCenter
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text,
                        color = style.colors[style.colorIdx].second,
                        fontSize = style.sizeSp.sp,
                        lineHeight = (style.sizeSp * 1.25f).sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        style = androidx.compose.ui.text.TextStyle(
                            shadow = if (style.bgIdx == 0) Shadow(Color.Black, GeoOffset(2f, 2f), 6f) else null
                        ),
                        modifier = Modifier
                            .then(
                                if (style.bgIdx == 1) Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.Black.copy(alpha = 0.65f))
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                                else Modifier
                            )
                    )
                    androidx.compose.foundation.layout.Spacer(
                        Modifier.fillMaxHeight(style.bottomPct / 100f + if (controls && !locked) 0.2f else 0.02f)
                    )
                }
            }
        }

        if (panel) {
            SubtitlePanel(
                subs = subs,
                textOptions = textOptions,
                audioOptions = audioOptions,
                onSelectOff = { selectOff() },
                onSelectText = { selectText(it) },
                onSelectAudio = { selectAudio(it) },
                onPickFile = { pickFile.launch(arrayOf("*/*")) },
                onClose = { panel = false }
            )
        }

        // ---- buffering spinner and errors ---------------------------------------------------
        if (buffering && playError == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = accent, modifier = Modifier.size(44.dp))
            }
        }
        playError?.let { msg ->
            Box(
                Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.8f)).padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Can't play this", fontSize = 20.sp, color = Color.White)
                    Text(
                        msg, color = Color(0xFFBDBDC4), fontSize = 14.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        modifier = Modifier.padding(top = 8.dp, bottom = 20.dp)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            "Try again", color = Color.Black,
                            modifier = Modifier
                                .clip(RoundedCornerShape(24.dp))
                                .background(accent)
                                .clickable { playError = null; retries = 0; player.prepare() }
                                .padding(horizontal = 24.dp, vertical = 10.dp)
                        )
                        Text(
                            "Close", color = Color.White,
                            modifier = Modifier
                                .clip(RoundedCornerShape(24.dp))
                                .background(Color(0xFF2A2A30))
                                .clickable(onClick = onBack)
                                .padding(horizontal = 24.dp, vertical = 10.dp)
                        )
                    }
                }
            }
        }

        // ---- HUD -----------------------------------------------------------------------------
        hud?.let { text ->
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    text,
                    color = Color.White,
                    fontSize = 20.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.Black.copy(alpha = 0.65f))
                        .padding(horizontal = 22.dp, vertical = 12.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        }

        // ---- controls ------------------------------------------------------------------------
        if (!inPip) {
            AnimatedVisibility(visible = controls, enter = fadeIn(), exit = fadeOut()) {
                if (locked) {
                    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.CenterStart) {
                        IconButton(
                            onClick = { locked = false; touch() },
                            modifier = Modifier.clip(CircleShape).background(Color.Black.copy(alpha = 0.6f))
                        ) { Icon(Icons.Filled.Lock, "Unlock", tint = accent) }
                    }
                } else {
                    Box(Modifier.fillMaxSize()) {
                        // top bar
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .background(Color.Black.copy(alpha = 0.5f))
                                .padding(horizontal = 4.dp, vertical = 4.dp)
                                .align(Alignment.TopCenter),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = onBack) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White)
                            }
                            Text(
                                title, Modifier.weight(1f), color = Color.White, fontSize = 15.sp,
                                maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                            )
                            Box {
                                Text(
                                    speedLabel(speed),
                                    color = if (speed == 1f) Color.White else accent,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable { speedMenu = true; touch() }
                                        .padding(horizontal = 12.dp, vertical = 8.dp)
                                )
                                DropdownMenu(expanded = speedMenu, onDismissRequest = { speedMenu = false }) {
                                    SPEEDS.forEach { s ->
                                        DropdownMenuItem(
                                            text = {
                                                Text(speedLabel(s), color = if (s == speed) accent else Color.White)
                                            },
                                            onClick = {
                                                speed = s
                                                player.setPlaybackSpeed(s)
                                                speedMenu = false
                                                hud = "Speed ${speedLabel(s)}"
                                            }
                                        )
                                    }
                                }
                            }
                            IconButton(onClick = {
                                aspectIdx = (aspectIdx + 1) % ASPECTS.size
                                zoom = 1f
                                hud = ASPECTS[aspectIdx].label
                                touch()
                            }) { Icon(Icons.Filled.AspectRatio, "Aspect ratio", tint = Color.White) }
                            IconButton(onClick = { panel = true; touch() }) {
                                Icon(
                                    Icons.Filled.Subtitles, "Subtitles and audio",
                                    tint = if (subs.source == SubSource.OFF) Color.White else accent
                                )
                            }
                            IconButton(onClick = onPip) {
                                Icon(Icons.Filled.PictureInPictureAlt, "Picture in picture", tint = Color.White)
                            }
                        }

                        // center transport
                        Row(
                            Modifier.align(Alignment.Center),
                            horizontalArrangement = Arrangement.spacedBy(28.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = {
                                player.seekTo((player.currentPosition - 10_000).coerceAtLeast(0)); touch()
                            }) { Icon(Icons.Filled.Replay10, "Back 10s", tint = Color.White, modifier = Modifier.size(36.dp)) }
                            Box(
                                Modifier
                                    .size(68.dp)
                                    .clip(CircleShape)
                                    .background(accent)
                                    .clickable { if (playing) player.pause() else player.play(); touch() },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                    "Play/Pause", tint = Color.Black, modifier = Modifier.size(38.dp)
                                )
                            }
                            IconButton(onClick = {
                                player.seekTo(
                                    (player.currentPosition + 10_000).let { p -> if (player.duration > 0) p.coerceAtMost(player.duration) else p }
                                ); touch()
                            }) { Icon(Icons.Filled.Forward10, "Forward 10s", tint = Color.White, modifier = Modifier.size(36.dp)) }
                        }

                        // bottom bar
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .background(Color.Black.copy(alpha = 0.5f))
                                .padding(horizontal = 16.dp, vertical = 6.dp)
                                .align(Alignment.BottomCenter)
                        ) {
                            val shown = sliderDrag ?: if (dur > 0) pos.toFloat() / dur else 0f
                            Slider(
                                value = shown.coerceIn(0f, 1f),
                                onValueChange = { sliderDrag = it; touch() },
                                onValueChangeFinished = {
                                    sliderDrag?.let { player.seekTo((it * dur).toLong()) }
                                    sliderDrag = null
                                },
                                colors = SliderDefaults.colors(
                                    thumbColor = accent,
                                    activeTrackColor = accent,
                                    inactiveTrackColor = Color.White.copy(alpha = 0.25f)
                                )
                            )
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                val shownPos = sliderDrag?.let { (it * dur).toLong() } ?: pos
                                Text(
                                    "${formatTime(shownPos)} / ${formatTime(dur)}",
                                    color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f)
                                )
                                IconButton(onClick = {
                                    orientIdx = (orientIdx + 1) % ORIENTS.size
                                    activity.requestedOrientation = ORIENTS[orientIdx].value
                                    hud = ORIENTS[orientIdx].label
                                    touch()
                                }) { Icon(Icons.Filled.ScreenRotation, "Rotate", tint = Color.White) }
                                IconButton(onClick = { locked = true; controls = true; touch() }) {
                                    Icon(Icons.Filled.LockOpen, "Lock controls", tint = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Turns a player error into a sentence a person can act on. */
private fun friendlyError(e: PlaybackException): String {
    val http = generateSequence<Throwable>(e) { it.cause }
        .filterIsInstance<HttpDataSource.InvalidResponseCodeException>().firstOrNull()
    if (http != null) {
        val c = http.responseCode
        return when (c) {
            401, 403 -> "The server refused access ($c). The link may need a login or may have expired."
            404, 410 -> "Link not found ($c). It may have been removed."
            in 500..599 -> "The server had a problem ($c). Try again later."
            else -> "The server answered with error $c."
        }
    }
    return when (e.errorCode) {
        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ->
            "Can't reach the server. Check your internet connection."
        PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND -> "File not found."
        PlaybackException.ERROR_CODE_IO_NO_PERMISSION -> "No permission to open this file."
        PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED,
        PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED,
        PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
        PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED ->
            "This isn't a video or audio file the player understands."
        PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
        PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED,
        PlaybackException.ERROR_CODE_DECODING_FAILED -> "This phone can't decode this format."
        else -> "Playback failed (${e.errorCodeName})."
    }
}
