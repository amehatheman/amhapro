package com.amha.player.data

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Optional online lookup on lrclib.net (free, no account). Only called when the user taps
 * "Find online". Sends artist, title, album and length of that one song, nothing else.
 */
object LrcLib {
    sealed interface Result {
        data class Found(val text: String, val synced: Boolean) : Result
        data object NotFound : Result
        data class Failed(val reason: String) : Result
    }

    fun fetch(artist: String, title: String, album: String, durationSec: Int): Result {
        return try {
            val q = StringBuilder("https://lrclib.net/api/get?")
                .append("track_name=").append(enc(title))
                .append("&artist_name=").append(enc(artist))
            if (album.isNotBlank() && album != "Unknown album") q.append("&album_name=").append(enc(album))
            if (durationSec > 0) q.append("&duration=").append(durationSec)

            val (code, body) = get(q.toString())
            when {
                code == 200 -> pick(JSONObject(body)) ?: searchFallback(artist, title)
                code == 404 -> searchFallback(artist, title)
                else -> Result.Failed("Server answered $code")
            }
        } catch (e: java.net.UnknownHostException) {
            Result.Failed("No internet connection")
        } catch (e: java.net.SocketTimeoutException) {
            Result.Failed("The lyrics server took too long")
        } catch (e: Throwable) {
            Result.Failed("Could not reach the lyrics server")
        }
    }

    private fun searchFallback(artist: String, title: String): Result {
        val (code, body) = get("https://lrclib.net/api/search?q=" + enc("$artist $title"))
        if (code != 200) return Result.NotFound
        val arr = JSONArray(body)
        var plainOnly: Result.Found? = null
        for (i in 0 until arr.length()) {
            when (val r = pick(arr.getJSONObject(i))) {
                is Result.Found -> if (r.synced) return r else if (plainOnly == null) plainOnly = r
                else -> {}
            }
        }
        return plainOnly ?: Result.NotFound
    }

    private fun pick(o: JSONObject): Result.Found? {
        val synced = o.optString("syncedLyrics", "").takeIf { it.isNotBlank() && it != "null" }
        if (synced != null) return Result.Found(synced, true)
        val plain = o.optString("plainLyrics", "").takeIf { it.isNotBlank() && it != "null" }
        return plain?.let { Result.Found(it, false) }
    }

    private fun get(url: String): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 10_000
        c.setRequestProperty("User-Agent", "AmhaPlayerPro/0.1")
        return try {
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            code to (stream?.bufferedReader()?.use { it.readText() } ?: "")
        } finally {
            c.disconnect()
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
}
