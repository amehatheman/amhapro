package com.amha.player.audio

import android.content.Context
import android.content.SharedPreferences
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToInt

/** A gain curve as (frequency Hz, dB) points. Works on any device band layout. */
typealias Curve = List<Pair<Int, Float>>

object EqPresets {
    private val ref = listOf(60, 230, 910, 3600, 14000)

    private fun c(vararg db: Float): Curve = ref.zip(db.toList())

    val builtIn: LinkedHashMap<String, Curve> = linkedMapOf(
        "Flat" to c(0f, 0f, 0f, 0f, 0f),
        "Rock" to c(4f, 2f, -2f, 3f, 5f),
        "Pop" to c(-1f, 2f, 4f, 2f, -1f),
        "Classical" to c(3f, 2f, -1f, 1f, 3f),
        "Jazz" to c(3f, 1f, -1f, 2f, 3f),
        "Electronic" to c(5f, 3f, 0f, 2f, 4f),
        "Hip-Hop" to c(5f, 4f, 0f, 1f, 3f),
        "Acoustic" to c(3f, 2f, 1f, 2f, 2f),
        "Vocal" to c(-2f, 0f, 4f, 3f, 1f),
        "Bass Boost" to c(6f, 4f, 0f, 0f, 0f)
    )
}

data class EqState(
    val supported: Boolean = false,
    val enabled: Boolean = false,
    val preset: String = "Flat",          // built-in name, saved custom name, or "Custom"
    val levels: List<Float> = emptyList(),  // dB per device band
    val bandFreqsHz: List<Int> = emptyList(),
    val minDb: Float = -12f,
    val maxDb: Float = 12f,
    val preampDb: Float = 0f,
    val bass: Int = 0,                     // 0..100
    val virtualizer: Int = 0,              // 0..100
    val antiClip: Boolean = true,
    val bassSupported: Boolean = false,
    val virtSupported: Boolean = false,
    val customNames: List<String> = emptyList()
)

/**
 * Attaches android.media.audiofx effects to the shared player's audio session and keeps
 * settings in SharedPreferences. Safe to use before a session exists: it simply waits.
 */
object EqualizerEngine {
    var state by mutableStateOf(EqState())
        private set

    private var eq: Equalizer? = null
    private var bassFx: BassBoost? = null
    private var virtFx: Virtualizer? = null
    private var loudFx: LoudnessEnhancer? = null

    private lateinit var prefs: SharedPreferences
    private lateinit var player: ExoPlayer
    private var customs = LinkedHashMap<String, Curve>()
    private var inited = false

    // Player volume = EQ headroom (baseVolume) x sleep-timer fade.
    private var baseVolume = 1f
    private var fadeFactor = 1f
    private var transitionFactor = 1f

    private fun pushVolume() {
        try { player.volume = (baseVolume * fadeFactor * transitionFactor).coerceIn(0f, 1f) } catch (_: Throwable) {}
    }

    fun setFade(f: Float) {
        fadeFactor = f.coerceIn(0f, 1f)
        if (inited) pushVolume()
    }

    /** Fade between songs (see TrackFader). Separate from the sleep-timer fade so they don't fight. */
    fun setTransitionFade(f: Float) {
        transitionFactor = f.coerceIn(0f, 1f)
        if (inited) pushVolume()
    }

    fun init(ctx: Context, p: ExoPlayer) {
        if (inited) return
        inited = true
        player = p
        prefs = ctx.applicationContext.getSharedPreferences("amha_eq", Context.MODE_PRIVATE)
        loadCustoms()
        state = state.copy(
            enabled = prefs.getBoolean("enabled", false),
            preset = prefs.getString("preset", "Flat") ?: "Flat",
            preampDb = prefs.getFloat("preamp", 0f),
            bass = prefs.getInt("bass", 0),
            virtualizer = prefs.getInt("virt", 0),
            antiClip = prefs.getBoolean("anticlip", true),
            customNames = customs.keys.toList()
        )
        p.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                attach(audioSessionId)
            }
        })
        attach(p.audioSessionId)
    }

    // ---- effect lifecycle ------------------------------------------------------------------

    private fun releaseEffects() {
        try { eq?.release() } catch (_: Throwable) {}
        try { bassFx?.release() } catch (_: Throwable) {}
        try { virtFx?.release() } catch (_: Throwable) {}
        try { loudFx?.release() } catch (_: Throwable) {}
        eq = null; bassFx = null; virtFx = null; loudFx = null
    }

    private fun attach(sessionId: Int) {
        releaseEffects()
        if (sessionId == 0) {
            state = state.copy(supported = false)
            return
        }
        try {
            val e = Equalizer(0, sessionId)
            eq = e
            val n = e.numberOfBands.toInt()
            val freqs = (0 until n).map { e.getCenterFreq(it.toShort()) / 1000 }
            val range = e.bandLevelRange
            val minDb = range[0] / 100f
            val maxDb = range[1] / 100f

            bassFx = try {
                BassBoost(0, sessionId).takeIf { it.strengthSupported }
            } catch (_: Throwable) { null }
            virtFx = try {
                Virtualizer(0, sessionId).takeIf { it.strengthSupported }
            } catch (_: Throwable) { null }
            loudFx = try { LoudnessEnhancer(sessionId) } catch (_: Throwable) { null }

            var levels = loadSavedLevels(n)
            if (levels == null) {
                levels = curveFor(state.preset)?.let { curveToLevels(it, freqs, minDb, maxDb) }
                    ?: List(n) { 0f }
            }
            state = state.copy(
                supported = true,
                bandFreqsHz = freqs,
                minDb = minDb,
                maxDb = maxDb,
                levels = levels,
                bassSupported = bassFx != null,
                virtSupported = virtFx != null
            )
            apply()
        } catch (_: Throwable) {
            releaseEffects()
            state = state.copy(supported = false)
        }
    }

    /** Pushes the current state into the live effects. */
    private fun apply() {
        val s = state
        val e = eq
        if (e != null) {
            try {
                e.enabled = s.enabled
                val lo = e.bandLevelRange[0].toInt()
                val hi = e.bandLevelRange[1].toInt()
                s.levels.forEachIndexed { i, db ->
                    e.setBandLevel(i.toShort(), (db * 100).roundToInt().coerceIn(lo, hi).toShort())
                }
            } catch (_: Throwable) {}
        }
        try {
            bassFx?.apply {
                setStrength((s.bass * 10).toShort())
                enabled = s.enabled && s.bass > 0
            }
        } catch (_: Throwable) {}
        try {
            virtFx?.apply {
                setStrength((s.virtualizer * 10).toShort())
                enabled = s.enabled && s.virtualizer > 0
            }
        } catch (_: Throwable) {}

        // Preamp + anti-clip. Negative totals use player volume, positive use LoudnessEnhancer.
        var total = 0f
        if (s.enabled) {
            total = s.preampDb
            if (s.antiClip) total -= max(0f, s.levels.maxOrNull() ?: 0f)
        }
        try {
            if (total < 0f) {
                baseVolume = 10f.pow(total / 20f)
                pushVolume()
                loudFx?.enabled = false
            } else {
                baseVolume = 1f
                pushVolume()
                loudFx?.apply {
                    setTargetGain((total * 100).roundToInt())
                    enabled = total > 0f
                }
            }
        } catch (_: Throwable) {}
    }

    // ---- user actions ----------------------------------------------------------------------

    fun setEnabled(on: Boolean) { state = state.copy(enabled = on); persist(); apply() }

    fun setPreset(name: String) {
        val curve = curveFor(name) ?: return
        val s = state
        if (s.bandFreqsHz.isEmpty()) {
            state = s.copy(preset = name); persist(); return
        }
        state = s.copy(
            preset = name,
            levels = curveToLevels(curve, s.bandFreqsHz, s.minDb, s.maxDb)
        )
        persist(); apply()
    }

    fun setBand(index: Int, db: Float) {
        val s = state
        if (index !in s.levels.indices) return
        val next = s.levels.toMutableList().also { it[index] = (db * 2).roundToInt() / 2f }
        state = s.copy(levels = next, preset = "Custom")
        persist(); apply()
    }

    fun setPreamp(db: Float) { state = state.copy(preampDb = (db * 2).roundToInt() / 2f); persist(); apply() }
    fun setBass(v: Int) { state = state.copy(bass = v.coerceIn(0, 100)); persist(); apply() }
    fun setVirtualizer(v: Int) { state = state.copy(virtualizer = v.coerceIn(0, 100)); persist(); apply() }
    fun setAntiClip(on: Boolean) { state = state.copy(antiClip = on); persist(); apply() }

    fun saveCustom(name: String) {
        val clean = name.trim().take(24)
        if (clean.isEmpty() || EqPresets.builtIn.containsKey(clean)) return
        val s = state
        customs[clean] = s.bandFreqsHz.zip(s.levels)
        state = s.copy(preset = clean, customNames = customs.keys.toList())
        persistCustoms(); persist()
    }

    fun deleteCustom(name: String) {
        if (customs.remove(name) == null) return
        state = state.copy(
            preset = if (state.preset == name) "Custom" else state.preset,
            customNames = customs.keys.toList()
        )
        persistCustoms(); persist()
    }

    fun renameCustom(old: String, new: String) {
        val clean = new.trim().take(24)
        val curve = customs[old] ?: return
        if (clean.isEmpty() || EqPresets.builtIn.containsKey(clean) || customs.containsKey(clean)) return
        // Rebuild map so order is kept.
        val rebuilt = LinkedHashMap<String, Curve>()
        customs.forEach { (k, v) -> rebuilt[if (k == old) clean else k] = if (k == old) curve else v }
        customs = rebuilt
        state = state.copy(
            preset = if (state.preset == old) clean else state.preset,
            customNames = customs.keys.toList()
        )
        persistCustoms(); persist()
    }

    // ---- helpers & storage -----------------------------------------------------------------

    private fun curveFor(name: String): Curve? = EqPresets.builtIn[name] ?: customs[name]

    private fun curveToLevels(curve: Curve, freqs: List<Int>, minDb: Float, maxDb: Float): List<Float> {
        val pts = curve.sortedBy { it.first }
        if (pts.isEmpty()) return List(freqs.size) { 0f }
        return freqs.map { f ->
            val db = when {
                f <= pts.first().first -> pts.first().second
                f >= pts.last().first -> pts.last().second
                else -> {
                    val hiIdx = pts.indexOfFirst { it.first >= f }
                    val (f0, d0) = pts[hiIdx - 1]
                    val (f1, d1) = pts[hiIdx]
                    val t = (ln(f.toFloat()) - ln(f0.toFloat())) / (ln(f1.toFloat()) - ln(f0.toFloat()))
                    d0 + (d1 - d0) * t
                }
            }
            ((db * 2).roundToInt() / 2f).coerceIn(minDb, maxDb)
        }
    }

    private fun loadSavedLevels(bandCount: Int): List<Float>? {
        val raw = prefs.getString("levels", null) ?: return null
        val parts = raw.split(",").mapNotNull { it.toFloatOrNull() }
        return if (parts.size == bandCount) parts else null
    }

    private fun persist() {
        prefs.edit()
            .putBoolean("enabled", state.enabled)
            .putString("preset", state.preset)
            .putString("levels", state.levels.joinToString(","))
            .putFloat("preamp", state.preampDb)
            .putInt("bass", state.bass)
            .putInt("virt", state.virtualizer)
            .putBoolean("anticlip", state.antiClip)
            .apply()
    }

    private fun persistCustoms() {
        val root = JSONObject()
        customs.forEach { (name, curve) ->
            val arr = JSONArray()
            curve.forEach { (hz, db) -> arr.put(JSONArray().put(hz).put(db.toDouble())) }
            root.put(name, arr)
        }
        prefs.edit().putString("customs", root.toString()).apply()
    }

    private fun loadCustoms() {
        customs = LinkedHashMap()
        val raw = prefs.getString("customs", null) ?: return
        try {
            val root = JSONObject(raw)
            root.keys().forEach { name ->
                val arr = root.getJSONArray(name)
                customs[name] = (0 until arr.length()).map { i ->
                    val p = arr.getJSONArray(i)
                    p.getInt(0) to p.getDouble(1).toFloat()
                }
            }
        } catch (_: Throwable) {
            customs = LinkedHashMap()
        }
    }
}
