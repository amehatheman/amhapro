package com.amha.player.ui

import android.content.Context
import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.amha.player.VideoActivity
import com.amha.player.data.MediaRepo
import com.amha.player.data.Track
import com.amha.player.data.VideoItem
import com.amha.player.playback.PlayerHolder
import com.amha.player.playback.rememberPlayerSnapshot
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private enum class Tab(val label: String) { MUSIC("Music"), VIDEOS("Videos"), SETTINGS("Settings") }

@Composable
fun AmhaRoot(
    mediaGranted: Boolean,
    vizGranted: Boolean,
    onRequestPermissions: () -> Unit
) {
    val ctx = LocalContext.current
    var accent by remember { mutableStateOf(Accents.load(ctx)) }

    AmhaTheme(accent) {
        var tab by remember { mutableStateOf(Tab.MUSIC) }
        var nowPlayingOpen by remember { mutableStateOf(false) }
        var eqOpen by remember { mutableStateOf(false) }
        var queueOpen by remember { mutableStateOf(false) }
        var lyricsOpen by remember { mutableStateOf(false) }
        val snap = rememberPlayerSnapshot()

        BackHandler(enabled = nowPlayingOpen) { nowPlayingOpen = false }
        BackHandler(enabled = lyricsOpen) { lyricsOpen = false }
        BackHandler(enabled = queueOpen) { queueOpen = false }
        BackHandler(enabled = eqOpen) { eqOpen = false }

        Box(Modifier.fillMaxSize().background(Color.Black)) {
            Scaffold(
                containerColor = Color.Black,
                bottomBar = {
                    Column {
                        if (snap.item != null) {
                            MiniPlayer(onOpen = { nowPlayingOpen = true })
                        }
                        NavigationBar(containerColor = Color(0xFF0B0B0D)) {
                            Tab.entries.forEach { t ->
                                NavigationBarItem(
                                    selected = tab == t,
                                    onClick = { tab = t },
                                    icon = {
                                        Icon(
                                            when (t) {
                                                Tab.MUSIC -> Icons.Filled.MusicNote
                                                Tab.VIDEOS -> Icons.Filled.VideoLibrary
                                                Tab.SETTINGS -> Icons.Filled.Settings
                                            }, t.label
                                        )
                                    },
                                    label = { Text(t.label) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Color.Black,
                                        indicatorColor = MaterialTheme.colorScheme.primary,
                                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                            }
                        }
                    }
                }
            ) { pad ->
                Box(Modifier.padding(pad).fillMaxSize()) {
                    when {
                        tab == Tab.SETTINGS -> SettingsScreen(
                            vizGranted = vizGranted,
                            onRequestPermissions = onRequestPermissions,
                            onOpenEq = { eqOpen = true },
                            onAccent = { i ->
                                Accents.save(ctx, i)
                                accent = Accents.options[i].second
                            }
                        )
                        !mediaGranted -> PermissionPrompt(onRequestPermissions)
                        tab == Tab.MUSIC -> MusicHome()
                        tab == Tab.VIDEOS -> VideosHome()
                    }
                }
            }

            if (nowPlayingOpen) {
                NowPlayingScreen(
                    visualizerAllowed = vizGranted,
                    onClose = { nowPlayingOpen = false },
                    onOpenEq = { eqOpen = true },
                    onOpenQueue = { queueOpen = true },
                    onOpenLyrics = { lyricsOpen = true }
                )
            }

            if (lyricsOpen) {
                LyricsScreen(onClose = { lyricsOpen = false })
            }

            if (queueOpen) {
                QueueScreen(onClose = { queueOpen = false })
            }

            if (eqOpen) {
                EqualizerScreen(onClose = { eqOpen = false })
            }
        }
    }
}

@Composable
private fun PermissionPrompt(onRequest: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Amha needs access to your media", fontSize = 18.sp)
        Text(
            "It only reads music and videos on this device. Nothing is uploaded.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 8.dp, bottom = 20.dp)
        )
        Box(
            Modifier
                .clip(RoundedCornerShape(24.dp))
                .background(MaterialTheme.colorScheme.primary)
                .clickable(onClick = onRequest)
                .padding(horizontal = 28.dp, vertical = 12.dp)
        ) { Text("Grant access", color = Color.Black) }
    }
}

@Composable
internal fun SearchField(value: String, onChange: (String) -> Unit, hint: String) {
    TextField(
        value = value,
        onValueChange = onChange,
        singleLine = true,
        placeholder = { Text(hint) },
        shape = RoundedCornerShape(14.dp),
        colors = TextFieldDefaults.colors(
            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
            focusedIndicatorColor = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent
        ),
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 10.dp)
    )
}

@Composable
internal fun ArtThumb(model: Any?, modifier: Modifier) {
    Box(modifier.background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
        Icon(
            Icons.Filled.MusicNote, null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(22.dp)
        )
        AsyncImage(
            model = model, contentDescription = null,
            contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
        )
    }
}

internal fun openVideo(ctx: Context, v: VideoItem) {
    PlayerHolder.player.pause() // don't talk over the music
    ctx.startActivity(
        Intent(ctx, VideoActivity::class.java)
            .putExtra(VideoActivity.EXTRA_URI, v.uri.toString())
            .putExtra(VideoActivity.EXTRA_TITLE, v.name)
    )
}

@Composable
private fun MiniPlayer(onOpen: () -> Unit) {
    val s = rememberPlayerSnapshot()
    val meta = s.item?.mediaMetadata
    val player = PlayerHolder.player
    Row(
        Modifier
            .fillMaxWidth()
            .background(Color(0xFF111114))
            .clickable(onClick = onOpen)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ArtThumb(meta?.artworkUri, Modifier.size(42.dp).clip(RoundedCornerShape(8.dp)))
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(meta?.title?.toString() ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
            Text(
                meta?.artist?.toString() ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis,
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        IconButton(onClick = { if (s.isPlaying) player.pause() else player.play() }) {
            Icon(
                if (s.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                "Play/Pause", tint = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
private fun SettingsScreen(
    vizGranted: Boolean,
    onRequestPermissions: () -> Unit,
    onOpenEq: () -> Unit,
    onAccent: (Int) -> Unit
) {
    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("Settings", fontSize = 26.sp, modifier = Modifier.padding(bottom = 20.dp))

        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .clickable(onClick = onOpenEq)
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.Tune, null, tint = MaterialTheme.colorScheme.primary)
            Column(Modifier.padding(start = 14.dp)) {
                Text("Equalizer", fontSize = 16.sp)
                Text(
                    "Bands, presets, bass boost, virtualizer",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Box(Modifier.height(24.dp))

        Text("ACCENT COLOR", fontSize = 12.sp, letterSpacing = 2.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        androidx.compose.foundation.layout.FlowRow(
            Modifier.padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            val current = MaterialTheme.colorScheme.primary
            Accents.options.forEachIndexed { i, (_, color) ->
                Box(
                    Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(color)
                        .then(
                            if (color == current) Modifier.border(3.dp, Color.White, CircleShape) else Modifier
                        )
                        .clickable { onAccent(i) }
                )
            }
        }

        val sctx = LocalContext.current
        val sprefs = remember { sctx.getSharedPreferences("amha", Context.MODE_PRIVATE) }
        var bufferMode by remember { mutableStateOf(sprefs.getInt("bufferMode", 1)) }
        Text(
            "STREAMING BUFFER", fontSize = 12.sp, letterSpacing = 2.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Small", "Normal", "Large").forEachIndexed { i, label ->
                val sel = bufferMode == i
                Text(
                    label, fontSize = 13.sp,
                    color = if (sel) Color.Black else Color.White,
                    modifier = Modifier
                        .clip(RoundedCornerShape(18.dp))
                        .background(if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                        .clickable { bufferMode = i; sprefs.edit().putInt("bufferMode", i).apply() }
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        }
        Text(
            "How much of a link is loaded ahead. Large is smoother on a weak connection but uses more memory and data.",
            color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp,
            modifier = Modifier.padding(top = 8.dp, bottom = 12.dp)
        )

        Text(
            "SONG FADE", fontSize = 12.sp, letterSpacing = 2.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        var fadeIdx by remember { mutableStateOf(sprefs.getInt("trackFade", 0).coerceIn(0, com.amha.player.audio.TrackFader.OPTIONS_SEC.lastIndex)) }
        GestureRow("Fade out and in between songs", com.amha.player.audio.TrackFader.OPTIONS_SEC.map { if (it == 0) "Off" else "${it}s" }, fadeIdx) {
            fadeIdx = it; com.amha.player.audio.TrackFader.setIndex(sctx, it)
        }
        Text(
            "Each song fades out at its end and the next fades in. It dips the volume rather than overlapping songs.",
            color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp,
            modifier = Modifier.padding(top = 8.dp, bottom = 12.dp)
        )

        Text(
            "HIDDEN FOLDERS", fontSize = 12.sp, letterSpacing = 2.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        val hiddenNow = com.amha.player.data.HiddenFolders.paths.toList().sorted()
        if (hiddenNow.isEmpty()) {
            Text(
                "None. Use HIDE on a folder in the Folders tab to remove it from your library.",
                color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp,
                modifier = Modifier.padding(top = 8.dp, bottom = 12.dp)
            )
        } else {
            hiddenNow.forEach { path ->
                Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        com.amha.player.data.Library.prettyPath(path), fontSize = 13.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                    )
                    Text(
                        "SHOW", fontSize = 11.sp, letterSpacing = 1.5.sp,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { com.amha.player.data.HiddenFolders.show(path) }
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                    )
                }
            }
            Box(Modifier.padding(bottom = 12.dp))
        }

        Text(
            "VIDEO GESTURES", fontSize = 12.sp, letterSpacing = 2.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        var skipIdx by remember { mutableStateOf(GesturePrefs.skipIndex(sctx)) }
        var sensIdx by remember { mutableStateOf(GesturePrefs.sensIndex(sctx)) }
        var holdIdx by remember { mutableStateOf(GesturePrefs.holdIndex(sctx)) }
        GestureRow("Double-tap skip", GesturePrefs.SKIP_SECONDS.map { "${it}s" }, skipIdx) {
            skipIdx = it; GesturePrefs.set(sctx, "gestSkip", it)
        }
        GestureRow("Swipe sensitivity", GesturePrefs.SENSITIVITY_LABELS, sensIdx) {
            sensIdx = it; GesturePrefs.set(sctx, "gestSens", it)
        }
        GestureRow("Hold to speed up", GesturePrefs.HOLD_SPEEDS.map { (if (it % 1f == 0f) it.toInt().toString() else it.toString()) + "x" }, holdIdx) {
            holdIdx = it; GesturePrefs.set(sctx, "holdSpeed", it)
        }
        Box(Modifier.padding(bottom = 12.dp))

        Text(
            "VISUALIZER", fontSize = 12.sp, letterSpacing = 2.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 20.dp)
        )
        Text(
            if (vizGranted) "Active. Tap the visualizer on the Now Playing screen to switch style."
            else "Needs the microphone permission, because Android only exposes the audio spectrum through it. Audio is analysed on-device and never recorded or sent anywhere.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 14.sp,
            modifier = Modifier.padding(top = 8.dp, bottom = 12.dp)
        )
        if (!vizGranted) {
            Box(
                Modifier
                    .clip(RoundedCornerShape(24.dp))
                    .background(MaterialTheme.colorScheme.primary)
                    .clickable(onClick = onRequestPermissions)
                    .padding(horizontal = 24.dp, vertical = 10.dp)
            ) { Text("Allow visualizer", color = Color.Black) }
        }

        Text(
            "Amha Player Pro 0.1.0",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 12.sp,
            modifier = Modifier.padding(top = 32.dp)
        )
    }
}

@Composable
private fun GestureRow(title: String, labels: List<String>, selected: Int, onPick: (Int) -> Unit) {
    Text(
        title, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp)
    )
    Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        labels.forEachIndexed { i, label ->
            val sel = selected == i
            Text(
                label, fontSize = 13.sp,
                color = if (sel) Color.Black else Color.White,
                modifier = Modifier
                    .clip(RoundedCornerShape(18.dp))
                    .background(if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                    .clickable { onPick(i) }
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }
    }
}
