package com.amha.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.amha.player.audio.EqPresets
import com.amha.player.audio.EqualizerEngine

private fun hzLabel(hz: Int): String =
    if (hz >= 1000) "%.1f kHz".format(hz / 1000f).replace(".0 ", " ") else "$hz Hz"

private fun dbLabel(db: Float): String = (if (db > 0) "+" else "") + "%.1f dB".format(db)

@Composable
fun EqualizerScreen(onClose: () -> Unit) {
    val s = EqualizerEngine.state
    val accent = MaterialTheme.colorScheme.primary
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    var dialog by remember { mutableStateOf<String?>(null) } // "save" | "rename"

    val sliderColors = SliderDefaults.colors(
        thumbColor = accent,
        activeTrackColor = accent,
        inactiveTrackColor = MaterialTheme.colorScheme.surfaceVariant,
        disabledThumbColor = dim,
        disabledActiveTrackColor = dim
    )

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .statusBarsPadding()
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) { Icon(Icons.Filled.KeyboardArrowDown, "Close") }
            Text("EQUALIZER", Modifier.weight(1f), fontSize = 13.sp, letterSpacing = 2.sp, color = dim)
            Switch(
                checked = s.enabled,
                onCheckedChange = { EqualizerEngine.setEnabled(it) },
                enabled = s.supported,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.Black,
                    checkedTrackColor = accent
                )
            )
            Box(Modifier.width(12.dp))
        }

        if (!s.supported) {
            Text(
                "The equalizer attaches to the audio output. Start playing a track and it will appear here.",
                color = dim,
                modifier = Modifier.padding(24.dp)
            )
            return@Column
        }

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(bottom = 24.dp)
        ) {
            // Presets
            val allPresets = EqPresets.builtIn.keys.toList() + s.customNames
            LazyRow(
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(allPresets) { name ->
                    val selected = s.preset == name
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (selected) accent else MaterialTheme.colorScheme.surfaceVariant)
                            .clickable { EqualizerEngine.setPreset(name) }
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Text(name, fontSize = 13.sp, color = if (selected) Color.Black else Color.White)
                    }
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    if (s.preset == "Custom") "Custom (unsaved)" else s.preset,
                    Modifier.weight(1f).padding(start = 4.dp), color = dim, fontSize = 13.sp
                )
                IconButton(onClick = { dialog = "save" }) { Icon(Icons.Filled.Save, "Save preset", tint = accent) }
                if (s.preset in s.customNames) {
                    IconButton(onClick = { dialog = "rename" }) { Icon(Icons.Filled.Edit, "Rename", tint = dim) }
                    IconButton(onClick = { EqualizerEngine.deleteCustom(s.preset) }) {
                        Icon(Icons.Filled.Delete, "Delete preset", tint = dim)
                    }
                }
            }

            Column(Modifier.alpha(if (s.enabled) 1f else 0.4f).padding(horizontal = 20.dp)) {
                Text("BANDS", fontSize = 12.sp, letterSpacing = 2.sp, color = dim, modifier = Modifier.padding(top = 8.dp))
                s.levels.forEachIndexed { i, db ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(hzLabel(s.bandFreqsHz[i]), Modifier.width(66.dp), fontSize = 13.sp)
                        Slider(
                            value = db.coerceIn(s.minDb, s.maxDb),
                            onValueChange = { EqualizerEngine.setBand(i, it) },
                            valueRange = s.minDb..s.maxDb,
                            enabled = s.enabled,
                            colors = sliderColors,
                            modifier = Modifier.weight(1f)
                        )
                        Text(dbLabel(db), Modifier.width(66.dp), fontSize = 12.sp, color = dim,
                            textAlign = androidx.compose.ui.text.style.TextAlign.End)
                    }
                }

                Text("PREAMP", fontSize = 12.sp, letterSpacing = 2.sp, color = dim, modifier = Modifier.padding(top = 20.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Slider(
                        value = s.preampDb,
                        onValueChange = { EqualizerEngine.setPreamp(it) },
                        valueRange = -12f..6f,
                        enabled = s.enabled,
                        colors = sliderColors,
                        modifier = Modifier.weight(1f)
                    )
                    Text(dbLabel(s.preampDb), Modifier.width(66.dp), fontSize = 12.sp, color = dim,
                        textAlign = androidx.compose.ui.text.style.TextAlign.End)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Anti-clip", fontSize = 15.sp)
                        Text(
                            "Lowers the level automatically when boosted bands could distort.",
                            fontSize = 12.sp, color = dim
                        )
                    }
                    Switch(
                        checked = s.antiClip,
                        onCheckedChange = { EqualizerEngine.setAntiClip(it) },
                        enabled = s.enabled,
                        colors = SwitchDefaults.colors(checkedThumbColor = Color.Black, checkedTrackColor = accent)
                    )
                }

                if (s.bassSupported) {
                    Text("BASS BOOST", fontSize = 12.sp, letterSpacing = 2.sp, color = dim, modifier = Modifier.padding(top = 20.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Slider(
                            value = s.bass.toFloat(),
                            onValueChange = { EqualizerEngine.setBass(it.toInt()) },
                            valueRange = 0f..100f,
                            enabled = s.enabled,
                            colors = sliderColors,
                            modifier = Modifier.weight(1f)
                        )
                        Text("${s.bass}%", Modifier.width(48.dp), fontSize = 12.sp, color = dim,
                            textAlign = androidx.compose.ui.text.style.TextAlign.End)
                    }
                }

                if (s.virtSupported) {
                    Text("VIRTUALIZER", fontSize = 12.sp, letterSpacing = 2.sp, color = dim, modifier = Modifier.padding(top = 12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Slider(
                            value = s.virtualizer.toFloat(),
                            onValueChange = { EqualizerEngine.setVirtualizer(it.toInt()) },
                            valueRange = 0f..100f,
                            enabled = s.enabled,
                            colors = sliderColors,
                            modifier = Modifier.weight(1f)
                        )
                        Text("${s.virtualizer}%", Modifier.width(48.dp), fontSize = 12.sp, color = dim,
                            textAlign = androidx.compose.ui.text.style.TextAlign.End)
                    }
                }

                if (!s.bassSupported || !s.virtSupported) {
                    Text(
                        "This device does not offer: " + listOfNotNull(
                            "bass boost".takeIf { !s.bassSupported },
                            "virtualizer".takeIf { !s.virtSupported }
                        ).joinToString(" or ") + ".",
                        fontSize = 12.sp, color = dim, modifier = Modifier.padding(top = 16.dp)
                    )
                }
            }
        }
    }

    dialog?.let { kind ->
        var text by remember(kind) { mutableStateOf(if (kind == "rename") s.preset else "") }
        AlertDialog(
            onDismissRequest = { dialog = null },
            containerColor = Color(0xFF141417),
            title = { Text(if (kind == "save") "Save preset" else "Rename preset") },
            text = {
                TextField(value = text, onValueChange = { text = it }, singleLine = true, placeholder = { Text("Preset name") })
            },
            confirmButton = {
                TextButton(onClick = {
                    if (kind == "save") EqualizerEngine.saveCustom(text)
                    else EqualizerEngine.renameCustom(s.preset, text)
                    dialog = null
                }) { Text("OK", color = accent) }
            },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("Cancel", color = dim) } }
        )
    }
}
