package com.amha.player.audio

/** Pure math for fading a song in at its start and out at its end. */
object FadeMath {
    private fun smooth(x: Float): Float {
        val t = x.coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    /**
     * Volume factor 0..1 for a song at [posMs]. [durMs] below zero means unknown (no fade out).
     * Songs shorter than three fade lengths are left alone so they don't sound pumped.
     */
    fun factor(posMs: Long, durMs: Long, fadeMs: Long): Float {
        if (fadeMs <= 0L || posMs < 0L) return 1f
        if (durMs in 0 until fadeMs * 3) return 1f
        val fadeIn = smooth(posMs.toFloat() / fadeMs)
        val fadeOut = if (durMs > 0) smooth((durMs - posMs).toFloat() / fadeMs) else 1f
        return fadeIn * fadeOut
    }

    /** True while a fade is in progress, so the caller knows to update often. */
    fun fading(posMs: Long, durMs: Long, fadeMs: Long): Boolean =
        factor(posMs, durMs, fadeMs) < 1f
}
