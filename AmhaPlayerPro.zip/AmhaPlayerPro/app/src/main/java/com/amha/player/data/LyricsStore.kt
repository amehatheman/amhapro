package com.amha.player.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import java.io.File

/** Lyrics saved on the phone, one text file per song, plus a per-song sync offset. */
object LyricsStore {
    /** Bumped on every change so Compose screens refresh. */
    var version by mutableIntStateOf(0)
        private set

    private lateinit var dir: File
    private lateinit var prefs: SharedPreferences

    fun init(ctx: Context) {
        if (::dir.isInitialized) return
        dir = File(ctx.applicationContext.filesDir, "lyrics").also { it.mkdirs() }
        prefs = ctx.applicationContext.getSharedPreferences("amha_lyrics", Context.MODE_PRIVATE)
    }

    fun load(id: Long): String? =
        try { File(dir, "$id.txt").takeIf { it.exists() }?.readText() } catch (_: Throwable) { null }

    fun save(id: Long, text: String) {
        try { File(dir, "$id.txt").writeText(text) } catch (_: Throwable) { return }
        version++
    }

    fun delete(id: Long) {
        try { File(dir, "$id.txt").delete() } catch (_: Throwable) {}
        prefs.edit().remove("off_$id").apply()
        version++
    }

    fun offset(id: Long): Long = prefs.getLong("off_$id", 0L)

    fun setOffset(id: Long, ms: Long) {
        prefs.edit().putLong("off_$id", ms).apply()
    }

    /** A .lrc next to the song file, if the app is allowed to read it. Silent on any failure. */
    fun readSibling(audioPath: String?): String? {
        if (audioPath.isNullOrBlank() || !audioPath.contains('.')) return null
        return try {
            val f = File(audioPath.substringBeforeLast('.') + ".lrc")
            if (f.isFile && f.canRead() && f.length() < 2_000_000) {
                SubtitleParser.decode(f.readBytes(), null)
            } else null
        } catch (_: Throwable) {
            null
        }
    }
}
