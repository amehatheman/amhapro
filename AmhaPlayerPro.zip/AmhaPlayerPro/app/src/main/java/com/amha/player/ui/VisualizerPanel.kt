package com.amha.player.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.amha.player.audio.VizConfig
import com.amha.player.audio.VizPalette
import com.amha.player.audio.VizPresets
import com.amha.player.audio.VizRange
import com.amha.player.audio.VizStyle

private val DIM = Color(0xFF9A9AA3)
private val CHIP_BG = Color(0xFF1F1F24)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VisualizerPanel(onClose: () -> Unit, onFullScreen: (() -> Unit)?) {
    val accent = MaterialTheme.colorScheme.primary
    val c = VizSettings.config
    var presetName by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .widthIn(max = 440.dp)
                .fillMaxWidth(0.94f)
                .heightIn(max = 640.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Color(0xFF141417))
                .verticalScroll(rememberScrollState())
                .padding(18.dp)
        ) {
            Label("STYLE")
            FlowRow(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                VizStyle.entries.forEach { s ->
                    Chip(s.label, c.style == s, accent) { VizSettings.update(c.copy(style = s)) }
                }
            }

            Label("PRESETS", top = 18)
            FlowRow(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                VizPresets.builtIn.forEach { (name, cfg) ->
                    Chip(name, c == cfg, accent) { VizSettings.update(cfg) }
                }
                VizSettings.customs.toSortedMap().forEach { (name, cfg) ->
                    Row(
                        Modifier
                            .clip(RoundedCornerShape(18.dp))
                            .background(if (c == cfg) accent else CHIP_BG),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val fg = if (c == cfg) Color.Black else Color.White
                        Text(
                            name, fontSize = 13.sp, color = fg,
                            modifier = Modifier
                                .clickable { VizSettings.update(cfg) }
                                .padding(start = 16.dp, top = 9.dp, bottom = 9.dp, end = 8.dp)
                        )
                        Text(
                            "✕", fontSize = 13.sp, color = fg.copy(alpha = 0.7f),
                            modifier = Modifier
                                .clickable { VizSettings.deleteCustom(name) }
                                .padding(start = 4.dp, end = 14.dp, top = 9.dp, bottom = 9.dp)
                        )
                    }
                }
            }
            Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(CHIP_BG)
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    if (presetName.isEmpty()) Text("Name this look", fontSize = 13.sp, color = DIM)
                    BasicTextField(
                        value = presetName,
                        onValueChange = { presetName = it.take(24) },
                        singleLine = true,
                        textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 13.sp),
                        cursorBrush = SolidColor(accent),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Text(
                    "SAVE", fontSize = 12.sp, letterSpacing = 1.5.sp,
                    color = if (presetName.isBlank()) DIM else accent,
                    modifier = Modifier
                        .padding(start = 6.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable(enabled = presetName.isNotBlank()) {
                            VizSettings.saveCustom(presetName)
                            presetName = ""
                        }
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                )
            }

            Label("TUNING", top = 18)
            SliderRow("Sensitivity", c.sensitivity, 0.4f..3f, "%.1fx".format(c.sensitivity), accent) { VizSettings.update(c.copy(sensitivity = it)) }
            SliderRow("Bars", c.bars.toFloat(), 12f..64f, "${c.bars}", accent) { VizSettings.update(c.copy(bars = it.toInt())) }
            SliderRow("Thickness", c.thickness, 0.2f..1f, "${(c.thickness * 100).toInt()}%", accent) { VizSettings.update(c.copy(thickness = it)) }
            SliderRow("Height", c.height, 0.3f..1f, "${(c.height * 100).toInt()}%", accent) { VizSettings.update(c.copy(height = it)) }
            SliderRow("Opacity", c.opacity, 0.2f..1f, "${(c.opacity * 100).toInt()}%", accent) { VizSettings.update(c.copy(opacity = it)) }
            SliderRow("Glow", c.glow, 0f..1f, "${(c.glow * 100).toInt()}%", accent) { VizSettings.update(c.copy(glow = it)) }
            SliderRow("Fall speed", c.speed, 0f..1f, if (c.speed < 0.34f) "Slow" else if (c.speed < 0.67f) "Medium" else "Fast", accent) { VizSettings.update(c.copy(speed = it)) }

            Label("COLOURS", top = 14)
            FlowRow(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                VizPalette.entries.forEach { p ->
                    val sel = c.palette == p
                    val swatch = if (p.stops.isEmpty()) listOf(accent, accent) else p.stops.map { Color(it) }
                    Row(
                        Modifier
                            .clip(RoundedCornerShape(18.dp))
                            .background(if (sel) accent else CHIP_BG)
                            .clickable { VizSettings.update(c.copy(palette = p)) }
                            .padding(horizontal = 12.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier
                                .widthIn(min = 22.dp)
                                .heightIn(min = 10.dp)
                                .clip(RoundedCornerShape(5.dp))
                                .background(Brush.horizontalGradient(swatch))
                                .padding(horizontal = 11.dp, vertical = 5.dp)
                        )
                        Text(
                            p.label, fontSize = 13.sp, modifier = Modifier.padding(start = 8.dp),
                            color = if (sel) Color.Black else Color.White
                        )
                    }
                }
            }

            Label("FREQUENCY RANGE", top = 14)
            FlowRow(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                VizRange.entries.forEach { r ->
                    Chip(r.label, c.range == r, accent) { VizSettings.update(c.copy(range = r)) }
                }
            }

            Row(Modifier.fillMaxWidth().padding(top = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (onFullScreen != null) {
                    ActionText("FULL SCREEN", accent, Modifier.weight(1f)) { onClose(); onFullScreen() }
                }
                ActionText("RESET", DIM, Modifier.weight(1f)) { VizSettings.update(VizConfig()) }
                ActionText("DONE", accent, Modifier.weight(1f), onClick = onClose)
            }
        }
    }
}

/** Visualizer only, edge to edge. Tap changes style, hold opens settings, back or X closes. */
@Composable
fun VisualizerFullScreen(
    audioSessionId: Int,
    isPlaying: Boolean,
    onClose: () -> Unit,
    onOpenSettings: () -> Unit
) {
    BackHandler(onBack = onClose)
    val accent = MaterialTheme.colorScheme.primary
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        SpectrumVisualizer(
            audioSessionId = audioSessionId,
            isPlaying = isPlaying,
            accent = accent,
            modifier = Modifier.fillMaxSize().padding(vertical = 56.dp, horizontal = 12.dp),
            onLongPress = onOpenSettings
        )
        IconButton(onClick = onClose, modifier = Modifier.statusBarsPadding().align(Alignment.TopEnd)) {
            Icon(Icons.Filled.Close, contentDescription = "Close", tint = Color.White.copy(alpha = 0.7f))
        }
        Text(
            "Tap: next style   ·   Hold: settings",
            color = Color.White.copy(alpha = 0.35f), fontSize = 12.sp,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 24.dp)
        )
    }
}

@Composable
private fun Label(text: String, top: Int = 0) {
    Text(text, fontSize = 11.sp, letterSpacing = 2.sp, color = DIM, modifier = Modifier.padding(top = top.dp))
}

@Composable
private fun Chip(label: String, selected: Boolean, accent: Color, onClick: () -> Unit) {
    Text(
        label, fontSize = 13.sp,
        color = if (selected) Color.Black else Color.White,
        modifier = Modifier
            .clip(RoundedCornerShape(18.dp))
            .background(if (selected) accent else CHIP_BG)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 9.dp)
    )
}

@Composable
private fun ActionText(label: String, color: Color, modifier: Modifier, onClick: () -> Unit) {
    Text(
        label, fontSize = 12.sp, letterSpacing = 1.5.sp, color = color,
        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(CHIP_BG)
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp)
    )
}

@Composable
private fun SliderRow(
    label: String, value: Float, range: ClosedFloatingPointRange<Float>,
    shown: String, accent: Color, onChange: (Float) -> Unit
) {
    Column(Modifier.padding(top = 6.dp)) {
        Row(Modifier.fillMaxWidth()) {
            Text(label, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text(shown, fontSize = 13.sp, color = DIM)
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = accent, activeTrackColor = accent, inactiveTrackColor = CHIP_BG
            )
        )
    }
}
