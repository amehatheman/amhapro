package com.amha.player.ui

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.amha.player.data.HiddenFolders
import com.amha.player.data.Library
import com.amha.player.data.MediaRepo
import com.amha.player.data.VideoItem
import com.amha.player.data.VideoSort
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private enum class VTab(val label: String) { ALL("All"), FOLDERS("Folders"), UNFINISHED("Unfinished"), LINKS("Links") }

@Composable
fun VideosHome() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("amha", Context.MODE_PRIVATE) }
    val resume = remember { ctx.getSharedPreferences("amha_resume", Context.MODE_PRIVATE) }
    var allVideos by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf(VTab.ALL) }
    var openFolder by remember { mutableStateOf<String?>(null) }
    var sort by remember {
        mutableStateOf(VideoSort.entries.getOrElse(prefs.getInt("videoSort", 0)) { VideoSort.NEWEST })
    }

    OnResumeTick { tick++ }
    LaunchedEffect(tick) {
        allVideos = withContext(Dispatchers.IO) { MediaRepo.loadVideos(ctx) }
        loaded = true
    }
    BackHandler(enabled = openFolder != null) { openFolder = null }

    val hidden = HiddenFolders.paths
    val videos = remember(allVideos, hidden) { Library.withoutFolders(allVideos, hidden) { it.folder } }

    val sorted = remember(videos, sort) { videos.sortedWith(sort.cmp) }
    val folders = remember(videos) { Library.videoFolders(videos) }
    // Read on every resume (tick) so progress saved by the player shows up straight away.
    val unfinished = remember(sorted, tick) {
        sorted.filter { resume.getLong("pos_${it.uri}", 0L) > 0L }
    }

    fun matches(v: VideoItem) = query.isBlank() || v.name.contains(query, true)

    Column(Modifier.fillMaxSize()) {
        val folderPath = openFolder
        val folderVideos = folders.firstOrNull { it.first == folderPath }?.second
        if (folderPath != null && folderVideos != null) {
            Row(
                Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { openFolder = null }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                Column(Modifier.weight(1f)) {
                    Text(Library.folderName(folderPath), fontSize = 19.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        "${folderVideos.size} videos · ${Library.prettyPath(folderPath)}",
                        fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            VideoList(folderVideos.sortedWith(sort.cmp), "")
        } else {
            SearchField(query, { query = it }, "Search videos")

            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(bottom = 6.dp)
            ) {
                items(VTab.entries.toList()) { t ->
                    val sel = tab == t
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                            .clickable { tab = t }
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) { Text(t.label, fontSize = 13.sp, color = if (sel) Color.Black else Color.White) }
                }
            }

            val emptyMsg = if (!loaded) "" else if (videos.isEmpty()) "No videos found on this device." else "No matches."
            when (tab) {
                VTab.LINKS -> LinksPane()
                VTab.ALL -> {
                    VideoSortBar(sort, sorted.count(::matches)) {
                        sort = it
                        prefs.edit().putInt("videoSort", it.ordinal).apply()
                    }
                    VideoList(sorted.filter(::matches), emptyMsg)
                }
                VTab.UNFINISHED -> VideoList(
                    unfinished.filter(::matches),
                    if (loaded) "No unfinished videos. Stop a video part-way and it shows up here." else ""
                )
                VTab.FOLDERS -> {
                    val list = folders.filter { (path, _) ->
                        query.isBlank() || Library.folderName(path).contains(query, true)
                    }
                    if (list.isEmpty() && emptyMsg.isNotEmpty()) {
                        Text(emptyMsg, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(24.dp))
                    }
                    LazyColumn(Modifier.fillMaxSize()) {
                        items(list, key = { it.first }) { (path, vs) ->
                            Row(
                                Modifier.fillMaxWidth().clickable { openFolder = path }
                                    .padding(horizontal = 16.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    Modifier
                                        .size(48.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant),
                                    contentAlignment = Alignment.Center
                                ) { Icon(Icons.Filled.Folder, null, tint = MaterialTheme.colorScheme.primary) }
                                Column(Modifier.weight(1f).padding(start = 14.dp)) {
                                    Text(Library.folderName(path), fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(
                                        "${vs.size} videos · ${Library.prettyPath(path)}",
                                        fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    "HIDE", fontSize = 11.sp, letterSpacing = 1.5.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable { HiddenFolders.hide(path) }
                                        .padding(horizontal = 10.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun VideoSortBar(current: VideoSort, count: Int, onPick: (VideoSort) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("$count videos", Modifier.weight(1f), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Box {
            Text(
                "Sort: ${current.label}  ▾",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { open = true }
                    .padding(horizontal = 10.dp, vertical = 8.dp)
            )
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                VideoSort.entries.forEach { s ->
                    DropdownMenuItem(
                        text = {
                            Text(s.label, color = if (s == current) MaterialTheme.colorScheme.primary else Color.White)
                        },
                        onClick = { onPick(s); open = false }
                    )
                }
            }
        }
    }
}

@Composable
private fun VideoList(list: List<VideoItem>, empty: String) {
    val ctx = LocalContext.current
    if (list.isEmpty() && empty.isNotEmpty()) {
        Text(empty, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(24.dp))
    }
    LazyColumn(Modifier.fillMaxSize()) {
        items(list, key = { it.id }) { v ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { openVideo(ctx, v) }
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .width(112.dp).height(64.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    AsyncImage(
                        model = v.uri, contentDescription = null,
                        contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
                    )
                }
                Column(Modifier.weight(1f).padding(start = 14.dp)) {
                    Text(v.name, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 15.sp)
                    Text(
                        "${formatTime(v.durationMs)} · ${"%.1f".format(v.sizeBytes / 1_048_576.0)} MB",
                        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
