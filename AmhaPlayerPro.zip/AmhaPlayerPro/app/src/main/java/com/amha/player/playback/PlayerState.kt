package com.amha.player.playback

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import kotlinx.coroutines.delay

data class PlayerSnapshot(
    val item: MediaItem? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val audioSessionId: Int = 0,
    val speed: Float = 1f
)

private fun snapshot(p: Player, sessionId: Int): PlayerSnapshot = PlayerSnapshot(
    item = p.currentMediaItem,
    isPlaying = p.isPlaying,
    positionMs = p.currentPosition,
    durationMs = if (p.duration > 0) p.duration else 0L,
    shuffle = p.shuffleModeEnabled,
    repeatMode = p.repeatMode,
    audioSessionId = sessionId,
    speed = p.playbackParameters.speed
)

/** Compose-friendly view of the shared music player. */
@Composable
fun rememberPlayerSnapshot(): PlayerSnapshot {
    val player = PlayerHolder.player
    var state by remember { mutableStateOf(snapshot(player, player.audioSessionId)) }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onEvents(p: Player, events: Player.Events) {
                state = snapshot(p, player.audioSessionId)
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }

    LaunchedEffect(state.isPlaying) {
        while (state.isPlaying) {
            state = snapshot(player, player.audioSessionId)
            delay(400)
        }
    }
    return state
}
