package com.amha.player.audio

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.random.Random

// Pure Kotlin: no Android or Compose types, so all of this can be tested on a computer.

enum class VizStyle(val label: String) {
    BARS("Bars"), MIRROR("Mirror"), RADIAL("Radial"), WAVE("Waveform"),
    FLOW("Flow"), RING("Ring wave"), PULSE("Pulse"), PARTICLES("Particles")
}

/** Which slice of the spectrum (on a log scale, 0 = lowest, 1 = highest) the bars show. */
enum class VizRange(val label: String, val from: Float, val to: Float) {
    FULL("Full", 0f, 1f), BASS("Bass", 0f, 0.45f), MID("Mid", 0.3f, 0.75f), HIGH("High", 0.55f, 1f)
}

/** Colour stops as 0xAARRGGBB. An empty list means "use the app accent colour". */
enum class VizPalette(val label: String, val stops: List<Long>) {
    ACCENT("Accent", emptyList()),
    NEON("Neon", listOf(0xFFFF3DCB, 0xFF3D8BFF, 0xFF3DFFE0)),
    FIRE("Fire", listOf(0xFFFF2D2D, 0xFFFF9A2D, 0xFFFFE14D)),
    OCEAN("Ocean", listOf(0xFF2D6BFF, 0xFF2DE1FF, 0xFF3DFFA0)),
    RAINBOW("Rainbow", listOf(0xFFFF4D4D, 0xFFFFC94D, 0xFF4DFF7C, 0xFF4DC9FF, 0xFF9B6BFF, 0xFFFF4DC9)),
    MONO("Mono", listOf(0xFFFFFFFF, 0xFF9A9AA3))
}

data class VizConfig(
    val style: VizStyle = VizStyle.BARS,
    val sensitivity: Float = 1f,   // 0.4 .. 3
    val bars: Int = 40,            // 12 .. 64
    val thickness: Float = 0.75f,  // share of each slot a bar fills, 0.2 .. 1
    val height: Float = 0.9f,      // 0.3 .. 1
    val opacity: Float = 0.9f,     // 0.2 .. 1
    val glow: Float = 0.3f,        // 0 .. 1
    val palette: VizPalette = VizPalette.ACCENT,
    val speed: Float = 0.5f,       // how fast bars fall, 0 .. 1
    val range: VizRange = VizRange.FULL
) {
    fun sanitized() = copy(
        sensitivity = sensitivity.coerceIn(0.4f, 3f),
        bars = bars.coerceIn(12, VizEngine.MAX_BANDS),
        thickness = thickness.coerceIn(0.2f, 1f),
        height = height.coerceIn(0.3f, 1f),
        opacity = opacity.coerceIn(0.2f, 1f),
        glow = glow.coerceIn(0f, 1f),
        speed = speed.coerceIn(0f, 1f)
    )

    fun encode(): String =
        "style=${style.name};sens=$sensitivity;bars=$bars;thick=$thickness;height=$height;" +
            "opacity=$opacity;glow=$glow;palette=${palette.name};speed=$speed;range=${range.name}"

    companion object {
        /** Reads what [encode] wrote. Anything missing or broken falls back to the default. */
        fun decode(s: String): VizConfig {
            val m = s.split(';').mapNotNull {
                val i = it.indexOf('=')
                if (i <= 0) null else it.substring(0, i).trim() to it.substring(i + 1).trim()
            }.toMap()
            val d = VizConfig()
            return VizConfig(
                style = m["style"]?.let { n -> VizStyle.entries.firstOrNull { it.name == n } } ?: d.style,
                sensitivity = m["sens"]?.toFloatOrNull() ?: d.sensitivity,
                bars = m["bars"]?.toIntOrNull() ?: d.bars,
                thickness = m["thick"]?.toFloatOrNull() ?: d.thickness,
                height = m["height"]?.toFloatOrNull() ?: d.height,
                opacity = m["opacity"]?.toFloatOrNull() ?: d.opacity,
                glow = m["glow"]?.toFloatOrNull() ?: d.glow,
                palette = m["palette"]?.let { n -> VizPalette.entries.firstOrNull { it.name == n } } ?: d.palette,
                speed = m["speed"]?.toFloatOrNull() ?: d.speed,
                range = m["range"]?.let { n -> VizRange.entries.firstOrNull { it.name == n } } ?: d.range
            ).sanitized()
        }
    }
}

object VizPresets {
    val builtIn: LinkedHashMap<String, VizConfig> = linkedMapOf(
        "Classic" to VizConfig(),
        "Neon" to VizConfig(style = VizStyle.MIRROR, palette = VizPalette.NEON, glow = 0.7f, bars = 32, thickness = 0.6f),
        "Calm" to VizConfig(style = VizStyle.FLOW, palette = VizPalette.OCEAN, speed = 0.25f, glow = 0.4f, opacity = 0.85f),
        "Bass hit" to VizConfig(style = VizStyle.PULSE, palette = VizPalette.FIRE, range = VizRange.BASS, sensitivity = 1.4f, glow = 0.6f),
        "Stardust" to VizConfig(style = VizStyle.PARTICLES, palette = VizPalette.RAINBOW, sensitivity = 1.2f, glow = 0.5f),
        "Scope" to VizConfig(style = VizStyle.WAVE, palette = VizPalette.NEON, glow = 0.5f, height = 0.7f)
    )
}

/** Small fixed-size particle pool. Positions are fractions of the canvas (0..1). */
class Particles(val max: Int = 140) {
    val x = FloatArray(max)
    val y = FloatArray(max)
    val vx = FloatArray(max)
    val vy = FloatArray(max)
    val life = FloatArray(max)
    val maxLife = FloatArray(max)
    val size = FloatArray(max)   // fraction of the shorter canvas side
    val t = FloatArray(max)      // palette position 0..1
    var count = 0
        private set

    private val rnd = Random(7)

    fun burst(n: Int, speed: Float) {
        repeat(n) {
            if (count >= max) return
            val a = rnd.nextFloat() * 2f * PI.toFloat()
            val v = speed * (0.4f + rnd.nextFloat() * 0.8f)
            x[count] = 0.5f
            y[count] = 0.5f
            vx[count] = cos(a) * v
            vy[count] = sin(a) * v
            maxLife[count] = 0.9f + rnd.nextFloat() * 1.4f
            life[count] = maxLife[count]
            size[count] = 0.004f + rnd.nextFloat() * 0.012f
            t[count] = rnd.nextFloat()
            count++
        }
    }

    fun step(dt: Float) {
        var i = 0
        val drag = 0.985f.pow(dt * 60f)
        while (i < count) {
            life[i] -= dt
            if (life[i] <= 0f) {
                val last = count - 1
                x[i] = x[last]; y[i] = y[last]; vx[i] = vx[last]; vy[i] = vy[last]
                life[i] = life[last]; maxLife[i] = maxLife[last]; size[i] = size[last]; t[i] = t[last]
                count--
                continue
            }
            x[i] += vx[i] * dt
            y[i] += vy[i] * dt
            vx[i] *= drag
            vy[i] *= drag
            i++
        }
    }
}

class VizEngine {
    companion object {
        const val MAX_BANDS = 64
        const val WAVE_POINTS = 96

        /**
         * Folds raw FFT bytes into [n] log-spaced bands in 0..1.
         * [fft] is Android's layout: byte pairs of (real, imaginary) after a DC/Nyquist pair.
         */
        fun mergeBands(fft: ByteArray, n: Int, range: VizRange, sensitivity: Float, out: FloatArray) {
            java.util.Arrays.fill(out, 0f)
            val bins = fft.size / 2 - 1
            if (bins < 2) return
            val count = n.coerceIn(1, out.size)
            for (b in 0 until count) {
                val f0 = range.from + (range.to - range.from) * b / count
                val f1 = range.from + (range.to - range.from) * (b + 1) / count
                var lo = bins.toDouble().pow(f0.toDouble()).toInt().coerceIn(1, bins - 1)
                var hi = bins.toDouble().pow(f1.toDouble()).toInt().coerceIn(lo + 1, bins)
                if (hi <= lo) hi = lo + 1
                var peak = 0f
                for (k in lo until hi) {
                    peak = max(peak, hypot(fft[2 * k].toFloat(), fft[2 * k + 1].toFloat()))
                }
                // Highs carry less energy; tilt slightly so they stay visible.
                val tilt = 1f + 0.6f * b / count
                out[b] = min(1f, peak / 90f * sensitivity * tilt)
            }
        }
    }

    val target = FloatArray(MAX_BANDS)
    val shown = FloatArray(MAX_BANDS)
    val waveTarget = FloatArray(WAVE_POINTS)
    val waveShown = FloatArray(WAVE_POINTS)
    val particles = Particles()

    var bass = 0f
        private set
    var mid = 0f
        private set
    var treble = 0f
        private set

    private var bassAvg = 0f
    private var beatCooldown = 0f
    private val rnd = Random(11)

    /** True when everything has faded out, so the render loop can go to sleep. */
    val quiet: Boolean
        get() = shown.all { it < 0.01f } && waveShown.all { abs(it) < 0.01f } && particles.count == 0

    fun onFft(fft: ByteArray, cfg: VizConfig) = mergeBands(fft, cfg.bars, cfg.range, cfg.sensitivity, target)

    /** Android gives unsigned bytes centred on 128. Keeps the loudest sample of each chunk. */
    fun onWave(bytes: ByteArray) {
        if (bytes.isEmpty()) return
        val chunk = max(1, bytes.size / WAVE_POINTS)
        for (i in 0 until WAVE_POINTS) {
            var best = 0f
            val start = i * chunk
            val end = min(bytes.size, start + chunk)
            for (j in start until end) {
                val v = ((bytes[j].toInt() and 0xFF) - 128) / 128f
                if (abs(v) > abs(best)) best = v
            }
            waveTarget[i] = best
        }
    }

    fun clearTargets() {
        java.util.Arrays.fill(target, 0f)
        java.util.Arrays.fill(waveTarget, 0f)
    }

    /** Advance by [dt] seconds. Bars rise fast and fall at the configured speed. */
    fun step(dt: Float, cfg: VizConfig) {
        val frames = dt * 60f
        val fall = 0.04f + 0.36f * cfg.speed
        val kFall = 1f - (1f - fall).pow(frames)
        val kRise = 1f - (1f - 0.65f).pow(frames)
        for (i in 0 until MAX_BANDS) {
            val t = target[i]
            val s = shown[i]
            shown[i] = s + (t - s) * (if (t > s) kRise else kFall)
        }
        val kWave = 1f - 0.5f.pow(frames)
        for (i in 0 until WAVE_POINTS) waveShown[i] += (waveTarget[i] - waveShown[i]) * kWave

        val n = cfg.bars.coerceIn(12, MAX_BANDS)
        bass = avg(0, max(1, n / 6))
        mid = avg(n / 6, max(n / 6 + 1, n / 2))
        treble = avg(n / 2, n)

        beatCooldown -= dt
        bassAvg = bassAvg * 0.97f + bass * 0.03f
        if (bass > 0.22f && bass > bassAvg * 1.3f && beatCooldown <= 0f) {
            particles.burst((5 + 16 * bass).toInt(), 0.25f + 0.5f * bass)
            beatCooldown = 0.14f
        }
        if (treble > 0.18f && rnd.nextFloat() < dt * 8f * treble) particles.burst(1, 0.1f)
        particles.step(dt)
    }

    private fun avg(from: Int, to: Int): Float {
        val a = from.coerceIn(0, MAX_BANDS)
        val b = to.coerceIn(a, MAX_BANDS)
        if (b == a) return 0f
        var s = 0f
        for (i in a until b) s += shown[i]
        return s / (b - a)
    }
}
