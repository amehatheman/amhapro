package com.amha.player.data

data class LyricLine(val timeMs: Long, val text: String)

/** [synced] true when lines carry timestamps. Plain lyrics have timeMs = 0 on every line. */
data class Lyrics(val synced: Boolean, val lines: List<LyricLine>)

object LrcParser {
    private val TIMESTAMP = Regex("""\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?]""")
    private val OFFSET = Regex("""^\[offset:\s*([+-]?\d+)\s*]""", RegexOption.IGNORE_CASE)
    private val META = Regex("""^\[[A-Za-z]+:[^\]]*]\s*$""")
    private val WORD_TIME = Regex("""<\d+:\d{2}(?:[.:]\d+)?>""")

    fun parse(raw: String): Lyrics {
        val text = raw.removePrefix("﻿").replace("\r\n", "\n").replace('\r', '\n')
        var offset = 0L
        val timed = mutableListOf<LyricLine>()
        val plain = mutableListOf<String>()

        for (line in text.split('\n')) {
            val l = line.trim()
            val off = OFFSET.find(l)
            if (off != null) {
                offset = off.groupValues[1].toLongOrNull() ?: 0L
                continue
            }
            val stamps = TIMESTAMP.findAll(l).toList()
            if (stamps.isNotEmpty()) {
                val body = WORD_TIME.replace(l.substring(stamps.last().range.last + 1), "").trim()
                for (m in stamps) {
                    val frac = m.groupValues[3]
                    val millis = when (frac.length) {
                        0 -> 0L
                        1 -> frac.toLong() * 100
                        2 -> frac.toLong() * 10
                        else -> frac.take(3).toLong()
                    }
                    val t = m.groupValues[1].toLong() * 60_000L + m.groupValues[2].toLong() * 1000L + millis
                    timed += LyricLine(t, body)
                }
            } else if (!META.matches(l)) {
                plain += l
            }
        }

        if (timed.isNotEmpty()) {
            // Positive [offset:] makes lyrics appear sooner, per the LRC convention.
            val lines = timed.map { it.copy(timeMs = (it.timeMs - offset).coerceAtLeast(0L)) }.sortedBy { it.timeMs }
            return Lyrics(true, lines)
        }

        // Plain text: keep stanza breaks, drop repeated blanks and blank edges.
        val cleaned = mutableListOf<String>()
        for (p in plain) if (p.isNotEmpty() || (cleaned.isNotEmpty() && cleaned.last().isNotEmpty())) cleaned += p
        while (cleaned.isNotEmpty() && cleaned.last().isEmpty()) cleaned.removeAt(cleaned.lastIndex)
        return Lyrics(false, cleaned.map { LyricLine(0L, it) })
    }

    /** Index of the line being sung at [posMs], or -1 before the first line. */
    fun indexAt(lines: List<LyricLine>, posMs: Long): Int {
        var lo = 0
        var hi = lines.lastIndex
        var found = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (lines[mid].timeMs <= posMs) { found = mid; lo = mid + 1 } else hi = mid - 1
        }
        return found
    }
}
