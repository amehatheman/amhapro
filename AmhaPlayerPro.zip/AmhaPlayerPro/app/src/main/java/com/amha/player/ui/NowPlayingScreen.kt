package com.amha.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import coil.compose.AsyncImage
import com.amha.player.audio.SleepTimer
import com.amha.player.data.PlaylistStore
import com.amha.player.playback.PlayerHolder
import com.amha.player.playback.rememberPlayerSnapshot

@Composable
fun NowPlayingScreen(
    visualizerAllowed: Boolean,
    onClose: () -> Unit,
    onOpenEq: () -> Unit,
    onOpenQueue: () -> Unit,
    onOpenLyrics: () -> Unit
) {
    val s = rememberPlayerSnapshot()
    val player = PlayerHolder.player
    val accent = MaterialTheme.colorScheme.primary
    val meta = s.item?.mediaMetadata
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableStateOf(0f) }
    var optionsOpen by remember { mutableStateOf(false) }
    var vizPanel by remember { mutableStateOf(false) }
    var vizFull by remember { mutableStateOf(false) }

    if (optionsOpen) PlaybackOptionsDialog(onClose = { optionsOpen = false })
    if (vizPanel) VisualizerPanel(
        onClose = { vizPanel = false },
        onFullScreen = if (visualizerAllowed) ({ vizFull = true }) else null
    )

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // Visualizer sits behind everything; tap cycles styles, hold opens its settings.
        if (visualizerAllowed && !vizFull) {
            SpectrumVisualizer(
                audioSessionId = s.audioSessionId,
                isPlaying = s.isPlaying,
                accent = accent,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 120.dp, bottom = 220.dp),
                onLongPress = { vizPanel = true }
            )
        }

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(horizontal = 24.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) {
                    Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Close")
                }
                Text(
                    "NOW PLAYING",
                    modifier = Modifier.weight(1f),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 12.sp,
                    letterSpacing = 2.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
                IconButton(onClick = onOpenQueue) {
                    Icon(Icons.AutoMirrored.Filled.QueueMusic, contentDescription = "Queue")
                }
                IconButton(onClick = { optionsOpen = true }) {
                    Icon(
                        Icons.Filled.Timer, contentDescription = "Sleep timer and speed",
                        tint = if (SleepTimer.active || s.speed != 1f) accent else LocalContentColor.current
                    )
                }
                IconButton(onClick = onOpenEq) {
                    Icon(Icons.Filled.Tune, contentDescription = "Equalizer")
                }
            }

            Box(
                Modifier
                    .padding(top = 12.dp)
                    .fillMaxWidth(0.78f)
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Filled.MusicNote, null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(64.dp)
                )
                AsyncImage(
                    model = meta?.artworkUri,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Box(Modifier.weight(1f))

            val currentId = s.item?.mediaId?.toLongOrNull()
            val isFav = currentId != null && currentId in PlaylistStore.data.favorites
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    meta?.title?.toString() ?: "Nothing playing",
                    fontSize = 22.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = { currentId?.let { PlaylistStore.toggleFavorite(it) } },
                    enabled = currentId != null
                ) {
                    Icon(
                        if (isFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                        "Favorite",
                        tint = if (isFav) accent else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Text(
                meta?.artist?.toString() ?: "",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 15.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            SleepTimer.label()?.let {
                Text(it, color = accent, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
            }
            Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf<Pair<String, () -> Unit>>("LYRICS" to onOpenLyrics, "VISUALIZER" to { vizPanel = true }).forEach { (label, action) ->
                    Text(
                        label,
                        color = accent,
                        fontSize = 12.sp,
                        letterSpacing = 2.sp,
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .clickable(onClick = action)
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }
            }

            val dur = s.durationMs.coerceAtLeast(1L)
            val shown = if (dragging) dragValue else s.positionMs.toFloat() / dur
            Slider(
                value = shown.coerceIn(0f, 1f),
                onValueChange = { dragging = true; dragValue = it },
                onValueChangeFinished = {
                    player.seekTo((dragValue * dur).toLong())
                    dragging = false
                },
                colors = SliderDefaults.colors(
                    thumbColor = accent,
                    activeTrackColor = accent,
                    inactiveTrackColor = MaterialTheme.colorScheme.surfaceVariant
                ),
                modifier = Modifier.padding(top = 8.dp)
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                val pos = if (dragging) (dragValue * dur).toLong() else s.positionMs
                Text(formatTime(pos), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(formatTime(s.durationMs), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp, bottom = 28.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { player.shuffleModeEnabled = !s.shuffle }) {
                    Icon(
                        Icons.Filled.Shuffle, "Shuffle",
                        tint = if (s.shuffle) accent else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = { player.seekToPreviousMediaItem() }) {
                    Icon(Icons.Filled.SkipPrevious, "Previous", modifier = Modifier.size(36.dp))
                }
                Box(
                    Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(accent)
                        .clickable { if (s.isPlaying) player.pause() else player.play() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        if (s.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        "Play/Pause", tint = Color.Black, modifier = Modifier.size(38.dp)
                    )
                }
                IconButton(onClick = { player.seekToNextMediaItem() }) {
                    Icon(Icons.Filled.SkipNext, "Next", modifier = Modifier.size(36.dp))
                }
                IconButton(onClick = {
                    player.repeatMode = when (s.repeatMode) {
                        Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                        Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                        else -> Player.REPEAT_MODE_OFF
                    }
                }) {
                    Icon(
                        if (s.repeatMode == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                        "Repeat",
                        tint = if (s.repeatMode == Player.REPEAT_MODE_OFF)
                            MaterialTheme.colorScheme.onSurfaceVariant else accent
                    )
                }
            }
        }
    }

    if (vizFull && visualizerAllowed) {
        VisualizerFullScreen(
            audioSessionId = s.audioSessionId,
            isPlaying = s.isPlaying,
            onClose = { vizFull = false },
            onOpenSettings = { vizPanel = true }
        )
    }
}
