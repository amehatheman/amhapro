package com.amha.player.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore

data class Track(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val uri: Uri,
    val artUri: Uri,
    val albumId: Long = 0L,
    val folder: String = "",
    val genre: String? = null,
    val dateAdded: Long = 0L,
    val sizeBytes: Long = 0L,
    val trackNo: Int = 0,
    val path: String = ""
)

data class VideoItem(
    val id: Long,
    val name: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val uri: Uri,
    val folder: String = "",
    val dateAdded: Long = 0L
)

object MediaRepo {

    fun loadTracks(ctx: Context): List<Track> {
        val out = mutableListOf<Track>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val hasGenre = Build.VERSION.SDK_INT >= 30
        val projection = buildList {
            add(MediaStore.Audio.Media._ID)
            add(MediaStore.Audio.Media.TITLE)
            add(MediaStore.Audio.Media.ARTIST)
            add(MediaStore.Audio.Media.ALBUM)
            add(MediaStore.Audio.Media.ALBUM_ID)
            add(MediaStore.Audio.Media.DURATION)
            add(MediaStore.Audio.Media.DATA)
            add(MediaStore.Audio.Media.DATE_ADDED)
            add(MediaStore.Audio.Media.SIZE)
            add(MediaStore.Audio.Media.TRACK)
            if (hasGenre) add(MediaStore.Audio.Media.GENRE)
        }.toTypedArray()
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > 15000"
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        ctx.contentResolver.query(collection, projection, selection, null, sort)?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val albumIdCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val durCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val dataCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            val addedCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            val sizeCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
            val trackCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
            val genreCol = if (hasGenre) c.getColumnIndex(MediaStore.Audio.Media.GENRE) else -1
            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                val albumId = c.getLong(albumIdCol)
                out += Track(
                    id = id,
                    title = c.getString(titleCol) ?: "Unknown",
                    artist = c.getString(artistCol).cleanArtist(),
                    album = c.getString(albumCol)?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: "Unknown album",
                    durationMs = c.getLong(durCol),
                    uri = ContentUris.withAppendedId(collection, id),
                    artUri = ContentUris.withAppendedId(
                        Uri.parse("content://media/external/audio/albumart"), albumId
                    ),
                    albumId = albumId,
                    folder = c.getString(dataCol).parentFolder(),
                    genre = if (genreCol >= 0) c.getString(genreCol)?.trim()?.takeIf { it.isNotEmpty() } else null,
                    dateAdded = c.getLong(addedCol),
                    sizeBytes = c.getLong(sizeCol),
                    // TRACK is disc*1000 + track on many files
                    trackNo = c.getInt(trackCol) % 1000,
                    path = c.getString(dataCol) ?: ""
                )
            }
        }
        return out
    }

    fun loadVideos(ctx: Context): List<VideoItem> {
        val out = mutableListOf<VideoItem>()
        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATA,
            MediaStore.Video.Media.DATE_ADDED
        )
        val sort = "${MediaStore.Video.Media.DATE_ADDED} DESC"
        ctx.contentResolver.query(collection, projection, null, null, sort)?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val nameCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val durCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            val sizeCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
            val dataCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)
            val addedCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                out += VideoItem(
                    id = id,
                    name = c.getString(nameCol) ?: "Video",
                    durationMs = c.getLong(durCol),
                    sizeBytes = c.getLong(sizeCol),
                    uri = ContentUris.withAppendedId(collection, id),
                    folder = c.getString(dataCol).parentFolder(),
                    dateAdded = c.getLong(addedCol)
                )
            }
        }
        return out
    }

    private fun String?.cleanArtist(): String =
        if (this.isNullOrBlank() || this == "<unknown>") "Unknown artist" else this

    private fun String?.parentFolder(): String =
        if (this.isNullOrBlank() || !contains('/')) "" else substringBeforeLast('/')
}
