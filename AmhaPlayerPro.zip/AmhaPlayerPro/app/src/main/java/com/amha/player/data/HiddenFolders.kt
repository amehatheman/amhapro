package com.amha.player.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Folders the user chose to hide from the music and video libraries. Files stay untouched. */
object HiddenFolders {
    var paths by mutableStateOf(emptySet<String>())
        private set

    private var prefs: SharedPreferences? = null

    fun init(ctx: Context) {
        if (prefs != null) return
        val p = ctx.applicationContext.getSharedPreferences("amha_library", Context.MODE_PRIVATE)
        prefs = p
        paths = p.getStringSet("hiddenFolders", emptySet())?.toSet() ?: emptySet()
    }

    fun hide(path: String) = save(paths + path)
    fun show(path: String) = save(paths - path)

    private fun save(s: Set<String>) {
        paths = s
        prefs?.edit()?.putStringSet("hiddenFolders", HashSet(s))?.apply()
    }
}
