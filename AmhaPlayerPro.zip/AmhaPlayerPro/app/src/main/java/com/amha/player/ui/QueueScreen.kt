package com.amha.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import com.amha.player.playback.PlayerHolder

/** The current play queue: tap to jump, arrows to reorder, X to remove. */
@Composable
fun QueueScreen(onClose: () -> Unit) {
    val player = PlayerHolder.player
    val accent = MaterialTheme.colorScheme.primary
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    var tick by remember { mutableIntStateOf(0) }

    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onTimelineChanged(timeline: Timeline, reason: Int) { tick++ }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { tick++ }
        }
        player.addListener(l)
        onDispose { player.removeListener(l) }
    }

    @Suppress("UNUSED_VARIABLE") val subscribe = tick
    val count = player.mediaItemCount
    val current = player.currentMediaItemIndex
    val items = List(count) { player.getMediaItemAt(it) }
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = current.coerceAtLeast(0))

    Column(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Filled.KeyboardArrowDown, "Close") }
            Text(
                "QUEUE · $count song${if (count == 1) "" else "s"}",
                Modifier.weight(1f), fontSize = 13.sp, letterSpacing = 2.sp, color = dim
            )
            if (count > current + 1) {
                TextButton(onClick = { player.removeMediaItems(current + 1, count) }) {
                    Text("Clear upcoming", color = accent, fontSize = 13.sp)
                }
            }
        }

        if (count == 0) {
            Text("The queue is empty. Play a song, or use ⋮ → Add to queue.", color = dim, modifier = Modifier.padding(24.dp))
        }

        LazyColumn(Modifier.fillMaxSize(), state = listState) {
            itemsIndexed(items) { i, item ->
                val meta = item.mediaMetadata
                val isCurrent = i == current
                Row(
                    Modifier
                        .fillMaxWidth()
                        .background(if (isCurrent) accent.copy(alpha = 0.12f) else Color.Transparent)
                        .clickable { player.seekToDefaultPosition(i); player.play() }
                        .padding(start = 16.dp, top = 6.dp, bottom = 6.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ArtThumb(meta.artworkUri, Modifier.size(48.dp).clip(RoundedCornerShape(8.dp)))
                    Column(Modifier.weight(1f).padding(start = 14.dp)) {
                        Text(
                            meta.title?.toString() ?: "Unknown",
                            maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 15.sp,
                            color = if (isCurrent) accent else Color.White
                        )
                        Text(
                            meta.artist?.toString() ?: "",
                            maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, color = dim
                        )
                    }
                    IconButton(onClick = { player.moveMediaItem(i, i - 1) }, enabled = i > 0) {
                        Icon(Icons.Filled.ArrowUpward, "Move up", modifier = Modifier.size(20.dp),
                            tint = if (i > 0) dim else dim.copy(alpha = 0.25f))
                    }
                    IconButton(onClick = { player.moveMediaItem(i, i + 1) }, enabled = i < count - 1) {
                        Icon(Icons.Filled.ArrowDownward, "Move down", modifier = Modifier.size(20.dp),
                            tint = if (i < count - 1) dim else dim.copy(alpha = 0.25f))
                    }
                    IconButton(onClick = { player.removeMediaItem(i) }) {
                        Icon(Icons.Filled.Close, "Remove", modifier = Modifier.size(20.dp), tint = dim)
                    }
                }
            }
        }
    }
}
