package com.amha.player.ui

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateMapOf
import com.amha.player.audio.VizConfig
import org.json.JSONObject

/** Visualizer settings, kept in memory as Compose state and saved to SharedPreferences. */
object VizSettings {
    private var prefs: SharedPreferences? = null

    var config by mutableStateOf(VizConfig())
        private set

    /** User presets: name -> settings. */
    val customs = mutableStateMapOf<String, VizConfig>()

    fun init(ctx: Context) {
        if (prefs != null) return
        val p = ctx.getSharedPreferences("amha_viz", Context.MODE_PRIVATE)
        prefs = p
        config = VizConfig.decode(p.getString("config", "") ?: "")
        try {
            val o = JSONObject(p.getString("customs", "{}") ?: "{}")
            for (k in o.keys()) customs[k] = VizConfig.decode(o.optString(k, ""))
        } catch (_: Throwable) {
        }
    }

    fun update(c: VizConfig) {
        config = c.sanitized()
        prefs?.edit()?.putString("config", config.encode())?.apply()
    }

    fun saveCustom(name: String) {
        val n = name.trim().take(24)
        if (n.isEmpty()) return
        customs[n] = config
        persistCustoms()
    }

    fun deleteCustom(name: String) {
        customs.remove(name)
        persistCustoms()
    }

    private fun persistCustoms() {
        val o = JSONObject()
        for ((k, v) in customs) o.put(k, v.encode())
        prefs?.edit()?.putString("customs", o.toString())?.apply()
    }
}
