package com.amha.player.audio

import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.Player
import com.amha.player.playback.PlayerHolder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Pauses music after a set time, fading the volume out over the last 15 seconds,
 * or at the end of the current song.
 */
object SleepTimer {
    private const val FADE_MS = 15_000L

    var remainingMs by mutableStateOf<Long?>(null)
        private set
    var endOfTrack by mutableStateOf(false)
        private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null
    private var listener: Player.Listener? = null

    val active: Boolean get() = remainingMs != null || endOfTrack

    fun start(minutes: Int) {
        cancel()
        val total = minutes * 60_000L
        val endAt = SystemClock.elapsedRealtime() + total
        remainingMs = total
        job = scope.launch {
            while (true) {
                val left = endAt - SystemClock.elapsedRealtime()
                if (left <= 0L) {
                    PlayerHolder.player.pause()
                    cancel()
                    break
                }
                remainingMs = left
                EqualizerEngine.setFade(fadeFor(left))
                delay(250)
            }
        }
    }

    fun startEndOfTrack() {
        cancel()
        endOfTrack = true
        val p = PlayerHolder.player
        p.pauseAtEndOfMediaItems = true
        val l = object : Player.Listener {
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                if (reason == Player.PLAY_WHEN_READY_CHANGE_REASON_END_OF_MEDIA_ITEM) cancel()
            }
        }
        listener = l
        p.addListener(l)
    }

    fun cancel() {
        job?.cancel()
        job = null
        remainingMs = null
        endOfTrack = false
        EqualizerEngine.setFade(1f)
        val p = PlayerHolder.player
        listener?.let { p.removeListener(it) }
        listener = null
        p.pauseAtEndOfMediaItems = false
    }

    /** Short text for the player screen, or null when no timer is running. */
    fun label(): String? {
        val left = remainingMs
        return when {
            endOfTrack -> "Sleep after this song"
            left != null -> "Sleep in " + clock(left)
            else -> null
        }
    }

    fun clock(ms: Long): String {
        val s = (ms + 999) / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }

    /** 1.0 until the last [FADE_MS], then straight down to 0. */
    fun fadeFor(leftMs: Long): Float =
        if (leftMs >= FADE_MS) 1f else (leftMs.toFloat() / FADE_MS).coerceIn(0f, 1f)
}
