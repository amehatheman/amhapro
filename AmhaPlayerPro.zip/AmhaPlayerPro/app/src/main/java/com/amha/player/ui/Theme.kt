package com.amha.player.ui

import android.content.Context
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color

object Accents {
    val options: List<Pair<String, Color>> = listOf(
        "Purple" to Color(0xFF9B6BFF),
        "Blue" to Color(0xFF4D8DFF),
        "Red" to Color(0xFFFF4D5E),
        "Green" to Color(0xFF3DDC84),
        "White" to Color(0xFFF2F2F2),
        "Orange" to Color(0xFFFF8A3D),
        "Pink" to Color(0xFFFF5CAA),
        "Cyan" to Color(0xFF3DDCFF),
        "Yellow" to Color(0xFFFFD84D),
        "Teal" to Color(0xFF2DD4BF),
        "Lime" to Color(0xFFB6F23D),
        "Crimson" to Color(0xFFD7263D)
    )

    fun load(ctx: Context): Color {
        val idx = ctx.getSharedPreferences("amha", Context.MODE_PRIVATE).getInt("accent", 0)
        return options.getOrElse(idx) { options[0] }.second
    }

    fun save(ctx: Context, index: Int) {
        ctx.getSharedPreferences("amha", Context.MODE_PRIVATE).edit().putInt("accent", index).apply()
    }
}

@Composable
fun AmhaTheme(accent: Color, content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = accent,
        onPrimary = Color.Black,
        background = Color.Black,
        onBackground = Color(0xFFEDEDED),
        surface = Color(0xFF0B0B0D),
        onSurface = Color(0xFFEDEDED),
        surfaceVariant = Color(0xFF17171B),
        onSurfaceVariant = Color(0xFF9A9AA3)
    )
    MaterialTheme(colorScheme = scheme) {
        // Overlay screens sit outside the Scaffold, so give them a light default text/icon colour.
        CompositionLocalProvider(LocalContentColor provides scheme.onBackground, content = content)
    }
}

fun formatTime(ms: Long): String {
    if (ms < 0) return "0:00"
    val total = ms / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}
