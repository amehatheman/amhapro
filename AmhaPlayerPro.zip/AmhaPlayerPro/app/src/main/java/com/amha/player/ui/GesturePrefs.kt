package com.amha.player.ui

import android.content.Context

/** Video gesture settings, read live from SharedPreferences so changes apply on the next video. */
object GesturePrefs {
    val SKIP_SECONDS = listOf(5, 10, 15, 30)
    val SENSITIVITY_LABELS = listOf("Low", "Normal", "High")
    private val SENSITIVITY = listOf(0.7f, 1f, 1.5f)
    val HOLD_SPEEDS = listOf(1.5f, 2f, 3f)

    private fun p(ctx: Context) = ctx.getSharedPreferences("amha", Context.MODE_PRIVATE)

    fun skipIndex(ctx: Context) = p(ctx).getInt("gestSkip", 1).coerceIn(0, SKIP_SECONDS.lastIndex)
    fun sensIndex(ctx: Context) = p(ctx).getInt("gestSens", 1).coerceIn(0, SENSITIVITY.lastIndex)
    fun holdIndex(ctx: Context) = p(ctx).getInt("holdSpeed", 1).coerceIn(0, HOLD_SPEEDS.lastIndex)

    fun skipMs(ctx: Context) = SKIP_SECONDS[skipIndex(ctx)] * 1000L
    fun sensitivity(ctx: Context) = SENSITIVITY[sensIndex(ctx)]
    fun holdSpeed(ctx: Context) = HOLD_SPEEDS[holdIndex(ctx)]

    fun set(ctx: Context, key: String, index: Int) {
        p(ctx).edit().putInt(key, index).apply()
    }
}
