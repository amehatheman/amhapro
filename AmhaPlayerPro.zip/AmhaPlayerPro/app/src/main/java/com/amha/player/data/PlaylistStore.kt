package com.amha.player.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Playlist(val id: String, val name: String, val trackIds: List<Long>)

data class LibraryData(
    val playlists: List<Playlist> = emptyList(),
    val favorites: List<Long> = emptyList(),
    val recent: List<Long> = emptyList()
)

/** Playlists, favorites and play history. Stored as JSON, observable from Compose. */
object PlaylistStore {
    var data by mutableStateOf(LibraryData())
        private set

    private lateinit var prefs: SharedPreferences
    private const val MAX_RECENT = 50

    fun init(ctx: Context) {
        if (::prefs.isInitialized) return
        prefs = ctx.applicationContext.getSharedPreferences("amha_library", Context.MODE_PRIVATE)
        data = load()
    }

    fun isFavorite(id: Long) = id in data.favorites

    fun toggleFavorite(id: Long) {
        val favs = data.favorites
        data = data.copy(favorites = if (id in favs) favs - id else listOf(id) + favs)
        save()
    }

    fun recordPlayed(id: Long) {
        data = data.copy(recent = (listOf(id) + data.recent.filter { it != id }).take(MAX_RECENT))
        save()
    }

    fun createPlaylist(name: String, firstTrack: Long? = null): String? {
        val clean = name.trim().take(40)
        if (clean.isEmpty()) return null
        val p = Playlist(UUID.randomUUID().toString(), clean, listOfNotNull(firstTrack))
        data = data.copy(playlists = data.playlists + p)
        save()
        return p.id
    }

    fun rename(id: String, name: String) {
        val clean = name.trim().take(40)
        if (clean.isEmpty()) return
        update(id) { it.copy(name = clean) }
    }

    fun delete(id: String) {
        data = data.copy(playlists = data.playlists.filter { it.id != id })
        save()
    }

    fun addTrack(playlistId: String, trackId: Long) =
        update(playlistId) { if (trackId in it.trackIds) it else it.copy(trackIds = it.trackIds + trackId) }

    fun removeAt(playlistId: String, index: Int) = update(playlistId) {
        if (index !in it.trackIds.indices) it
        else it.copy(trackIds = it.trackIds.toMutableList().also { l -> l.removeAt(index) })
    }

    fun move(playlistId: String, from: Int, to: Int) = update(playlistId) {
        if (from !in it.trackIds.indices || to !in it.trackIds.indices) it
        else it.copy(trackIds = it.trackIds.toMutableList().also { l -> l.add(to, l.removeAt(from)) })
    }

    private fun update(id: String, f: (Playlist) -> Playlist) {
        data = data.copy(playlists = data.playlists.map { if (it.id == id) f(it) else it })
        save()
    }

    private fun save() {
        val root = JSONObject()
        root.put("favorites", JSONArray(data.favorites))
        root.put("recent", JSONArray(data.recent))
        val pl = JSONArray()
        data.playlists.forEach { p ->
            pl.put(
                JSONObject()
                    .put("id", p.id)
                    .put("name", p.name)
                    .put("tracks", JSONArray(p.trackIds))
            )
        }
        root.put("playlists", pl)
        prefs.edit().putString("data", root.toString()).apply()
    }

    private fun load(): LibraryData {
        val raw = prefs.getString("data", null) ?: return LibraryData()
        return try {
            val root = JSONObject(raw)
            fun longs(a: JSONArray?) = if (a == null) emptyList() else (0 until a.length()).map { a.getLong(it) }
            val pls = root.optJSONArray("playlists")
            LibraryData(
                playlists = if (pls == null) emptyList() else (0 until pls.length()).map { i ->
                    val o = pls.getJSONObject(i)
                    Playlist(o.getString("id"), o.getString("name"), longs(o.optJSONArray("tracks")))
                },
                favorites = longs(root.optJSONArray("favorites")),
                recent = longs(root.optJSONArray("recent"))
            )
        } catch (_: Throwable) {
            LibraryData()
        }
    }
}
