package com.amha.player.data

import android.net.Uri

data class AlbumGroup(
    val id: Long,
    val title: String,
    val artist: String,
    val artUri: Uri,
    val tracks: List<Track>
)

/** Artist, genre or folder: a name plus its songs. */
data class NamedGroup(val key: String, val tracks: List<Track>) {
    val albumCount: Int get() = tracks.map { it.albumId }.distinct().size
}

enum class SongSort(val label: String, val cmp: Comparator<Track>) {
    TITLE("Title A–Z", compareBy<Track> { it.title.lowercase() }),
    ARTIST("Artist A–Z", compareBy<Track> { it.artist.lowercase() }.thenBy { it.title.lowercase() }),
    NEWEST("Recently added", compareByDescending<Track> { it.dateAdded }),
    OLDEST("Oldest added", compareBy<Track> { it.dateAdded }),
    LONGEST("Longest", compareByDescending<Track> { it.durationMs }),
    SHORTEST("Shortest", compareBy<Track> { it.durationMs }),
    LARGEST("Largest file", compareByDescending<Track> { it.sizeBytes })
}

enum class VideoSort(val label: String, val cmp: Comparator<VideoItem>) {
    NEWEST("Newest", compareByDescending<VideoItem> { it.dateAdded }),
    NAME("Name A–Z", compareBy<VideoItem> { it.name.lowercase() }),
    LONGEST("Longest", compareByDescending<VideoItem> { it.durationMs }),
    LARGEST("Largest file", compareByDescending<VideoItem> { it.sizeBytes })
}

object Library {

    /** Drops items whose folder the user hid. */
    fun <T> withoutFolders(items: List<T>, hidden: Set<String>, folderOf: (T) -> String): List<T> =
        if (hidden.isEmpty()) items else items.filter { folderOf(it) !in hidden }

    fun albums(tracks: List<Track>): List<AlbumGroup> =
        tracks.groupBy { it.albumId }
            .map { (id, ts) ->
                val artist = ts.groupingBy { it.artist }.eachCount().maxByOrNull { it.value }?.key ?: ""
                val distinctArtists = ts.map { it.artist }.distinct().size
                AlbumGroup(
                    id = id,
                    title = ts.first().album,
                    artist = if (distinctArtists > 3) "Various artists" else artist,
                    artUri = ts.first().artUri,
                    tracks = ts.sortedWith(compareBy<Track> { it.trackNo }.thenBy { it.title.lowercase() })
                )
            }
            .sortedBy { it.title.lowercase() }

    fun artists(tracks: List<Track>): List<NamedGroup> =
        tracks.groupBy { it.artist }
            .map { (k, ts) -> NamedGroup(k, ts.sortedWith(compareBy<Track> { it.album.lowercase() }.thenBy { it.trackNo })) }
            .sortedBy { it.key.lowercase() }

    fun genres(tracks: List<Track>): List<NamedGroup> =
        tracks.filter { it.genre != null }
            .groupBy { it.genre!!.lowercase() }
            .map { (_, ts) -> NamedGroup(ts.first().genre!!, ts.sortedBy { it.title.lowercase() }) }
            .sortedBy { it.key.lowercase() }

    fun musicFolders(tracks: List<Track>): List<NamedGroup> =
        tracks.groupBy { it.folder }
            .map { (k, ts) -> NamedGroup(k, ts.sortedBy { it.title.lowercase() }) }
            .sortedBy { folderName(it.key).lowercase() }

    fun videoFolders(videos: List<VideoItem>): List<Pair<String, List<VideoItem>>> =
        videos.groupBy { it.folder }
            .map { (k, vs) -> k to vs.sortedByDescending { it.dateAdded } }
            .sortedBy { folderName(it.first).lowercase() }

    fun folderName(path: String): String =
        path.substringAfterLast('/').ifEmpty { "Internal storage" }

    fun prettyPath(path: String): String =
        path.removePrefix("/storage/emulated/0").removePrefix("/storage/").trim('/').ifEmpty { "Internal storage" }
}
