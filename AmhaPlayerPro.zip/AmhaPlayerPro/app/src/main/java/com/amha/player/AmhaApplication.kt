package com.amha.player

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.VideoFrameDecoder
import com.amha.player.data.LinkStore
import com.amha.player.playback.PlayerHolder

class AmhaApplication : Application(), ImageLoaderFactory {
    override fun onCreate() {
        super.onCreate()
        PlayerHolder.init(this)
        LinkStore.init(this)
        com.amha.player.data.HiddenFolders.init(this)
        com.amha.player.ui.VizSettings.init(this)
    }

    override fun newImageLoader(): ImageLoader =
        ImageLoader.Builder(this)
            .components { add(VideoFrameDecoder.Factory()) }
            .crossfade(true)
            .build()
}
