package com.amha.player.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.amha.player.data.LrcLib
import com.amha.player.data.LrcParser
import com.amha.player.data.LyricsStore
import com.amha.player.data.SubtitleParser
import com.amha.player.playback.PlayerHolder
import com.amha.player.playback.rememberPlayerSnapshot
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Lyrics for the song that is playing. Synced lines scroll along; tap a line to jump there. */
@Composable
fun LyricsScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val accent = MaterialTheme.colorScheme.primary
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    val player = PlayerHolder.player

    val snap = rememberPlayerSnapshot()
    val item = snap.item
    val id = item?.mediaId?.toLongOrNull()
    val meta = item?.mediaMetadata

    val version = LyricsStore.version
    val raw = remember(id, version) { id?.let { LyricsStore.load(it) } }
    val lyrics = remember(raw) { raw?.let { LrcParser.parse(it) }?.takeIf { it.lines.isNotEmpty() } }

    var offsetMs by remember(id) { mutableLongStateOf(id?.let { LyricsStore.offset(it) } ?: 0L) }
    var pos by remember { mutableLongStateOf(0L) }
    var message by remember(id) { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var pasteOpen by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }

    LaunchedEffect(player) {
        while (true) {
            pos = player.currentPosition
            delay(150)
        }
    }

    // Try a .lrc sitting next to the song the first time we see a song without lyrics.
    LaunchedEffect(id) {
        if (id != null && LyricsStore.load(id) == null) {
            val path = meta?.extras?.getString("path")
            val text = withContext(Dispatchers.IO) { LyricsStore.readSibling(path) }
            if (text != null && LrcParser.parse(text).lines.isNotEmpty()) LyricsStore.save(id, text)
        }
    }

    fun findOnline() {
        val songId = id ?: return
        if (busy) return
        busy = true
        message = "Searching…"
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                LrcLib.fetch(
                    artist = meta?.artist?.toString().orEmpty(),
                    title = meta?.title?.toString().orEmpty(),
                    album = meta?.albumTitle?.toString().orEmpty(),
                    durationSec = (snap.durationMs / 1000).toInt()
                )
            }
            busy = false
            when (result) {
                is LrcLib.Result.Found -> {
                    LyricsStore.save(songId, result.text)
                    message = if (result.synced) null else "Found plain lyrics (no timing)."
                }
                LrcLib.Result.NotFound -> message = "No lyrics found online for this song."
                is LrcLib.Result.Failed -> message = result.reason
            }
        }
    }

    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val songId = id
        if (uri != null && songId != null) scope.launch {
            val text = withContext(Dispatchers.IO) {
                try {
                    ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                        ?.takeIf { it.size < 2_000_000 }
                        ?.let { SubtitleParser.decode(it, null) }
                } catch (_: Throwable) { null }
            }
            if (text != null && LrcParser.parse(text).lines.isNotEmpty()) {
                LyricsStore.save(songId, text)
                message = null
            } else message = "Could not read lyrics from that file."
        }
    }

    Column(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Filled.KeyboardArrowDown, "Close") }
            Column(Modifier.weight(1f)) {
                Text(meta?.title?.toString() ?: "Lyrics", fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(meta?.artist?.toString() ?: "", fontSize = 12.sp, color = dim, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Box {
                IconButton(onClick = { menuOpen = true }) { Icon(Icons.Filled.MoreVert, "More", tint = dim) }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(text = { Text("Find online") }, onClick = { menuOpen = false; findOnline() })
                    DropdownMenuItem(text = { Text("Load from file…") }, onClick = { menuOpen = false; pickFile.launch(arrayOf("*/*")) })
                    DropdownMenuItem(text = { Text("Paste lyrics…") }, onClick = { menuOpen = false; pasteOpen = true })
                    if (raw != null) {
                        DropdownMenuItem(
                            text = { Text("Delete lyrics", color = Color(0xFFFF6B6B)) },
                            onClick = { menuOpen = false; id?.let { LyricsStore.delete(it) } }
                        )
                    }
                }
            }
        }

        if (lyrics == null) {
            Column(
                Modifier.weight(1f).fillMaxWidth().padding(28.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("No lyrics for this song yet", fontSize = 18.sp)
                Text(
                    message ?: "Load a .lrc or .txt file, paste the words, or look them up online.",
                    color = dim, fontSize = 14.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 8.dp, bottom = 20.dp)
                )
                ActionPill("Find online", accent, Color.Black, enabled = !busy && id != null) { findOnline() }
                Box(Modifier.padding(top = 10.dp))
                ActionPill("Load from file", Color(0xFF1F1F24), Color.White, enabled = id != null) { pickFile.launch(arrayOf("*/*")) }
                Box(Modifier.padding(top = 10.dp))
                ActionPill("Paste lyrics", Color(0xFF1F1F24), Color.White, enabled = id != null) { pasteOpen = true }
                Text(
                    "Find online sends this song's artist, title and album to lrclib.net. Nothing else leaves your phone.",
                    color = dim, fontSize = 11.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 16.dp)
                )
            }
        } else {
            val lines = lyrics.lines
            val current = if (lyrics.synced) LrcParser.indexAt(lines, pos + offsetMs) else -1
            val listState = rememberLazyListState()

            LaunchedEffect(current) {
                if (current >= 0) {
                    val h = listState.layoutInfo.viewportSize.height
                    listState.animateScrollToItem(current, scrollOffset = -(h / 3))
                }
            }

            message?.let { Text(it, color = dim, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp)) }

            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 24.dp, vertical = 160.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                itemsIndexed(lines) { i, line ->
                    val isCurrent = i == current
                    Text(
                        line.text.ifEmpty { if (lyrics.synced) "♪" else " " },
                        fontSize = if (lyrics.synced) (if (isCurrent) 26.sp else 21.sp) else 18.sp,
                        fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                        color = when {
                            !lyrics.synced -> Color.White
                            isCurrent -> accent
                            i < current -> Color(0xFF6A6A72)
                            else -> Color(0xFF9A9AA3)
                        },
                        lineHeight = 30.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .then(
                                if (lyrics.synced) Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { player.seekTo((line.timeMs - offsetMs).coerceAtLeast(0L)) }
                                else Modifier
                            )
                    )
                }
            }

            if (lyrics.synced) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = { offsetMs += 500; id?.let { LyricsStore.setOffset(it, offsetMs) } }) {
                        Text("Earlier", color = accent)
                    }
                    Text(
                        when {
                            offsetMs > 0 -> "%.1f s earlier".format(offsetMs / 1000f)
                            offsetMs < 0 -> "%.1f s later".format(-offsetMs / 1000f)
                            else -> "In sync"
                        },
                        Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 12.sp, color = dim
                    )
                    TextButton(onClick = { offsetMs -= 500; id?.let { LyricsStore.setOffset(it, offsetMs) } }) {
                        Text("Later", color = accent)
                    }
                }
            }
        }
    }

    if (pasteOpen) {
        var text by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { pasteOpen = false },
            containerColor = Color(0xFF141417),
            title = { Text("Paste lyrics") },
            text = {
                TextField(
                    value = text, onValueChange = { text = it },
                    placeholder = { Text("Plain words, or LRC lines like [01:23.45] text") },
                    minLines = 6, maxLines = 10, modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (id != null && LrcParser.parse(text).lines.isNotEmpty()) {
                        LyricsStore.save(id, text)
                        message = null
                    }
                    pasteOpen = false
                }) { Text("Save", color = accent) }
            },
            dismissButton = { TextButton(onClick = { pasteOpen = false }) { Text("Cancel", color = dim) } }
        )
    }
}

@Composable
private fun ActionPill(label: String, bg: Color, fg: Color, enabled: Boolean, onClick: () -> Unit) {
    Text(
        label, color = fg, fontSize = 15.sp, textAlign = TextAlign.Center,
        modifier = Modifier
            .fillMaxWidth(0.7f)
            .clip(RoundedCornerShape(26.dp))
            .background(if (enabled) bg else bg.copy(alpha = 0.4f))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(vertical = 13.dp)
    )
}
