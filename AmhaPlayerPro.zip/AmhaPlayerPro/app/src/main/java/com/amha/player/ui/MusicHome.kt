package com.amha.player.ui

import android.content.Context
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.PlaylistAdd
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.amha.player.data.AlbumGroup
import com.amha.player.data.HiddenFolders
import com.amha.player.data.Library
import com.amha.player.data.MediaRepo
import com.amha.player.data.NamedGroup
import com.amha.player.data.Playlist
import com.amha.player.data.PlaylistStore
import com.amha.player.data.SongSort
import com.amha.player.data.Track
import com.amha.player.playback.PlayerHolder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private enum class LibTab(val label: String) {
    SONGS("Songs"), ALBUMS("Albums"), ARTISTS("Artists"), GENRES("Genres"),
    FOLDERS("Folders"), FAVORITES("Favorites"), RECENT("Recent"), PLAYLISTS("Playlists")
}

private sealed interface Detail {
    data class AlbumD(val id: Long) : Detail
    data class ArtistD(val name: String) : Detail
    data class GenreD(val name: String) : Detail
    data class FolderD(val path: String) : Detail
    data class PlaylistD(val id: String) : Detail
}

private sealed interface LibDialog {
    data class AddTo(val track: Track) : LibDialog
    data class NewPlaylist(val withTrack: Long?) : LibDialog
    data class Rename(val id: String, val current: String) : LibDialog
}

/** Calls [onResume] every time the app comes back to the foreground, so lists stay fresh. */
@Composable
internal fun OnResumeTick(onResume: () -> Unit) {
    val act = LocalContext.current as? ComponentActivity ?: return
    DisposableEffect(act) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) onResume() }
        act.lifecycle.addObserver(o)
        onDispose { act.lifecycle.removeObserver(o) }
    }
}

@Composable
fun MusicHome() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("amha", Context.MODE_PRIVATE) }
    var allTracks by remember { mutableStateOf<List<Track>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    var reloadTick by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf(LibTab.SONGS) }
    var detail by remember { mutableStateOf<Detail?>(null) }
    var dialog by remember { mutableStateOf<LibDialog?>(null) }
    var sort by remember {
        mutableStateOf(SongSort.entries.getOrElse(prefs.getInt("songSort", 0)) { SongSort.TITLE })
    }

    OnResumeTick { reloadTick++ }
    LaunchedEffect(reloadTick) {
        allTracks = withContext(Dispatchers.IO) { MediaRepo.loadTracks(ctx) }
        loaded = true
    }

    val hidden = HiddenFolders.paths
    val tracks = remember(allTracks, hidden) { Library.withoutFolders(allTracks, hidden) { it.folder } }
    var albumList by remember { mutableStateOf(prefs.getBoolean("albumList", false)) }
    val byId = remember(tracks) { tracks.associateBy { it.id } }
    val albums = remember(tracks) { Library.albums(tracks) }
    val artists = remember(tracks) { Library.artists(tracks) }
    val genres = remember(tracks) { Library.genres(tracks) }
    val folders = remember(tracks) { Library.musicFolders(tracks) }
    val sorted = remember(tracks, sort) { tracks.sortedWith(sort.cmp) }
    val data = PlaylistStore.data

    val albumD = (detail as? Detail.AlbumD)?.let { d -> albums.firstOrNull { it.id == d.id } }
    val artistD = (detail as? Detail.ArtistD)?.let { d -> artists.firstOrNull { it.key == d.name } }
    val genreD = (detail as? Detail.GenreD)?.let { d -> genres.firstOrNull { it.key == d.name } }
    val folderD = (detail as? Detail.FolderD)?.let { d -> folders.firstOrNull { it.key == d.path } }
    val playlistD = (detail as? Detail.PlaylistD)?.let { d -> data.playlists.firstOrNull { it.id == d.id } }
    val inDetail = albumD != null || artistD != null || genreD != null || folderD != null || playlistD != null
    BackHandler(enabled = inDetail) { detail = null }

    fun q(s: String) = query.isBlank() || s.contains(query, true)
    fun matches(t: Track) = q(t.title) || q(t.artist) || q(t.album)
    val addTo: (Track) -> Unit = { dialog = LibDialog.AddTo(it) }

    Column(Modifier.fillMaxSize()) {
        when {
            albumD != null -> CollectionDetail(
                albumD.title, albumD.artist, albumD.tracks, albumD.artUri, { detail = null }, addTo
            )
            artistD != null -> CollectionDetail(
                artistD.key, "${artistD.tracks.size} songs · ${artistD.albumCount} albums",
                artistD.tracks, null, { detail = null }, addTo
            )
            genreD != null -> CollectionDetail(
                genreD.key, "${genreD.tracks.size} songs", genreD.tracks, null, { detail = null }, addTo
            )
            folderD != null -> CollectionDetail(
                Library.folderName(folderD.key), Library.prettyPath(folderD.key),
                folderD.tracks, null, { detail = null }, addTo
            )
            playlistD != null -> PlaylistDetail(
                playlist = playlistD,
                byId = byId,
                onBack = { detail = null },
                onRename = { dialog = LibDialog.Rename(playlistD.id, playlistD.name) },
                onDelete = { PlaylistStore.delete(playlistD.id); detail = null }
            )
            else -> {
                SearchField(query, { query = it }, "Search your music")

                val visibleTabs = LibTab.entries.filter { it != LibTab.GENRES || genres.isNotEmpty() }
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(bottom = 6.dp)
                ) {
                    items(visibleTabs) { t ->
                        val sel = tab == t
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { tab = t }
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                        ) { Text(t.label, fontSize = 13.sp, color = if (sel) Color.Black else Color.White) }
                    }
                }

                val emptyMsg = if (!loaded) "" else if (tracks.isEmpty()) "No music found on this device." else "No matches."
                when (if (tab == LibTab.GENRES && genres.isEmpty()) LibTab.SONGS else tab) {
                    LibTab.SONGS -> {
                        SortBar(sort, count = sorted.count(::matches)) {
                            sort = it
                            prefs.edit().putInt("songSort", it.ordinal).apply()
                        }
                        TrackList(sorted.filter(::matches), emptyMsg, addTo)
                    }
                    LibTab.ALBUMS -> {
                        val list = albums.filter { q(it.title) || q(it.artist) }
                        if (list.isEmpty() && emptyMsg.isNotEmpty()) EmptyText(emptyMsg)
                        ViewToggle(albumList) {
                            albumList = it
                            prefs.edit().putBoolean("albumList", it).apply()
                        }
                        if (albumList) AlbumList(list) { detail = Detail.AlbumD(it.id) }
                        else AlbumGrid(list) { detail = Detail.AlbumD(it.id) }
                    }
                    LibTab.ARTISTS -> {
                        val list = artists.filter { q(it.key) }
                        if (list.isEmpty() && emptyMsg.isNotEmpty()) EmptyText(emptyMsg)
                        GroupList(
                            list, Icons.Filled.Person,
                            title = { it.key },
                            subtitle = { "${it.tracks.size} songs · ${it.albumCount} albums" }
                        ) { detail = Detail.ArtistD(it.key) }
                    }
                    LibTab.GENRES -> {
                        val list = genres.filter { q(it.key) }
                        if (list.isEmpty() && emptyMsg.isNotEmpty()) EmptyText(emptyMsg)
                        GroupList(
                            list, Icons.Filled.Category,
                            title = { it.key },
                            subtitle = { "${it.tracks.size} songs" }
                        ) { detail = Detail.GenreD(it.key) }
                    }
                    LibTab.FOLDERS -> {
                        val list = folders.filter { q(Library.folderName(it.key)) || q(it.key) }
                        if (list.isEmpty() && emptyMsg.isNotEmpty()) EmptyText(emptyMsg)
                        GroupList(
                            list, Icons.Filled.Folder,
                            title = { Library.folderName(it.key) },
                            subtitle = { "${it.tracks.size} songs · ${Library.prettyPath(it.key)}" },
                            onHide = { HiddenFolders.hide(it.key) }
                        ) { detail = Detail.FolderD(it.key) }
                    }
                    LibTab.FAVORITES -> TrackList(
                        data.favorites.mapNotNull { byId[it] }.filter(::matches),
                        "No favorites yet. Tap ⋮ on a song, or the heart on the player.", addTo
                    )
                    LibTab.RECENT -> TrackList(
                        data.recent.mapNotNull { byId[it] }.filter(::matches), "Nothing played yet.", addTo
                    )
                    LibTab.PLAYLISTS -> PlaylistList(
                        data.playlists.filter { q(it.name) },
                        onOpen = { detail = Detail.PlaylistD(it.id) },
                        onNew = { dialog = LibDialog.NewPlaylist(null) }
                    )
                }
            }
        }
    }

    when (val d = dialog) {
        is LibDialog.AddTo -> AlertDialog(
            onDismissRequest = { dialog = null },
            containerColor = Color(0xFF141417),
            title = { Text("Add to playlist") },
            text = {
                Column {
                    Text(
                        "+ New playlist",
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { dialog = LibDialog.NewPlaylist(d.track.id) }
                            .padding(vertical = 12.dp)
                    )
                    data.playlists.forEach { p ->
                        Text(
                            p.name,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    PlaylistStore.addTrack(p.id, d.track.id)
                                    dialog = null
                                }
                                .padding(vertical = 12.dp)
                        )
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { dialog = null }) {
                    Text("Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        )
        is LibDialog.NewPlaylist -> NameDialog("New playlist", "", { dialog = null }) { name ->
            PlaylistStore.createPlaylist(name, d.withTrack)
            dialog = null
        }
        is LibDialog.Rename -> NameDialog("Rename playlist", d.current, { dialog = null }) { name ->
            PlaylistStore.rename(d.id, name)
            dialog = null
        }
        null -> {}
    }
}

// ---- small building blocks -------------------------------------------------------------------

@Composable
private fun EmptyText(text: String) {
    Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(24.dp))
}

@Composable
private fun SortBar(current: SongSort, count: Int, onPick: (SongSort) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "$count songs", Modifier.weight(1f), fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Box {
            Text(
                "Sort: ${current.label}  ▾",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { open = true }
                    .padding(horizontal = 10.dp, vertical = 8.dp)
            )
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                SongSort.entries.forEach { s ->
                    DropdownMenuItem(
                        text = {
                            Text(s.label, color = if (s == current) MaterialTheme.colorScheme.primary else Color.White)
                        },
                        onClick = { onPick(s); open = false }
                    )
                }
            }
        }
    }
}

@Composable
private fun NameDialog(title: String, initial: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF141417),
        title = { Text(title) },
        text = {
            TextField(value = text, onValueChange = { text = it }, singleLine = true, placeholder = { Text("Name") })
        },
        confirmButton = {
            TextButton(onClick = { onOk(text) }) { Text("OK", color = MaterialTheme.colorScheme.primary) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    )
}

@Composable
private fun TrackRow(t: Track, onClick: () -> Unit, trailing: @Composable () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = 16.dp, top = 6.dp, bottom = 6.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ArtThumb(t.artUri, Modifier.size(52.dp).clip(RoundedCornerShape(8.dp)))
        Column(Modifier.weight(1f).padding(start = 14.dp)) {
            Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 16.sp)
            Text(
                t.artist, maxLines = 1, overflow = TextOverflow.Ellipsis,
                fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        trailing()
    }
}

@Composable
private fun SongMenu(t: Track, onAddTo: () -> Unit) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    val fav = t.id in PlaylistStore.data.favorites
    Box {
        IconButton(onClick = { open = true }) {
            Icon(Icons.Filled.MoreVert, "More", tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(
                text = { Text(if (fav) "Remove from favorites" else "Add to favorites") },
                leadingIcon = { Icon(Icons.Filled.Favorite, null, tint = if (fav) MaterialTheme.colorScheme.primary else Color.Gray) },
                onClick = { PlaylistStore.toggleFavorite(t.id); open = false }
            )
            DropdownMenuItem(
                text = { Text("Add to playlist") },
                leadingIcon = { Icon(Icons.AutoMirrored.Filled.PlaylistAdd, null) },
                onClick = { open = false; onAddTo() }
            )
            DropdownMenuItem(
                text = { Text("Play next") },
                leadingIcon = { Icon(Icons.Filled.SkipNext, null) },
                onClick = {
                    open = false
                    PlayerHolder.playNext(t)
                    Toast.makeText(ctx, "Playing next", Toast.LENGTH_SHORT).show()
                }
            )
            DropdownMenuItem(
                text = { Text("Add to queue") },
                leadingIcon = { Icon(Icons.AutoMirrored.Filled.QueueMusic, null) },
                onClick = {
                    open = false
                    PlayerHolder.addToQueue(t)
                    Toast.makeText(ctx, "Added to queue", Toast.LENGTH_SHORT).show()
                }
            )
        }
    }
}

@Composable
private fun TrackList(list: List<Track>, empty: String, onAddTo: (Track) -> Unit) {
    if (list.isEmpty() && empty.isNotEmpty()) EmptyText(empty)
    LazyColumn(Modifier.fillMaxSize()) {
        itemsIndexed(list, key = { _, t -> t.id }) { index, t ->
            TrackRow(t, onClick = { PlayerHolder.playQueue(list, index) }) {
                SongMenu(t) { onAddTo(t) }
            }
        }
    }
}

@Composable
private fun ViewToggle(list: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.End) {
        Text(
            if (list) "GRID VIEW" else "LIST VIEW", fontSize = 11.sp, letterSpacing = 1.5.sp,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .clickable { onChange(!list) }
                .padding(horizontal = 10.dp, vertical = 8.dp)
        )
    }
}

@Composable
private fun AlbumList(albums: List<AlbumGroup>, onOpen: (AlbumGroup) -> Unit) {
    LazyColumn(Modifier.fillMaxSize()) {
        items(albums, key = { it.id }) { a ->
            Row(
                Modifier.fillMaxWidth().clickable { onOpen(a) }.padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ArtThumb(a.artUri, Modifier.size(56.dp).clip(RoundedCornerShape(10.dp)))
                Column(Modifier.weight(1f).padding(start = 14.dp)) {
                    Text(a.title, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        "${a.artist} · ${a.tracks.size} songs", fontSize = 12.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun AlbumGrid(albums: List<AlbumGroup>, onOpen: (AlbumGroup) -> Unit) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(albums, key = { it.id }) { a ->
            Column(
                Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { onOpen(a) }
                    .padding(6.dp)
            ) {
                ArtThumb(a.artUri, Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(12.dp)))
                Text(
                    a.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp)
                )
                Text(
                    "${a.artist} · ${a.tracks.size}", maxLines = 1, overflow = TextOverflow.Ellipsis,
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun GroupList(
    list: List<NamedGroup>,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: (NamedGroup) -> String,
    subtitle: (NamedGroup) -> String,
    onHide: ((NamedGroup) -> Unit)? = null,
    onOpen: (NamedGroup) -> Unit
) {
    LazyColumn(Modifier.fillMaxSize()) {
        items(list, key = { it.key }) { g ->
            Row(
                Modifier.fillMaxWidth().clickable { onOpen(g) }.padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary) }
                Column(Modifier.weight(1f).padding(start = 14.dp)) {
                    Text(title(g), fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        subtitle(g), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (onHide != null) {
                    Text(
                        "HIDE", fontSize = 11.sp, letterSpacing = 1.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { onHide(g) }
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun PlayShuffleRow(list: List<Track>) {
    val accent = MaterialTheme.colorScheme.primary
    Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            Modifier
                .clip(RoundedCornerShape(24.dp))
                .background(accent)
                .clickable(enabled = list.isNotEmpty()) {
                    PlayerHolder.player.shuffleModeEnabled = false
                    PlayerHolder.playQueue(list, 0)
                }
                .padding(horizontal = 18.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.PlayArrow, null, tint = Color.Black, modifier = Modifier.size(20.dp))
            Text("Play", color = Color.Black, modifier = Modifier.padding(start = 6.dp))
        }
        Row(
            Modifier
                .clip(RoundedCornerShape(24.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .clickable(enabled = list.isNotEmpty()) {
                    PlayerHolder.playQueue(list, list.indices.random())
                    PlayerHolder.player.shuffleModeEnabled = true
                }
                .padding(horizontal = 18.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.Shuffle, null, modifier = Modifier.size(20.dp))
            Text("Shuffle", modifier = Modifier.padding(start = 6.dp))
        }
    }
}

/** Album, artist, genre or folder: header, play/shuffle, then its songs. */
@Composable
private fun CollectionDetail(
    title: String,
    subtitle: String,
    tracks: List<Track>,
    art: Any?,
    onBack: () -> Unit,
    onAddTo: (Track) -> Unit
) {
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 4.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
        if (art != null) {
            ArtThumb(art, Modifier.size(52.dp).clip(RoundedCornerShape(10.dp)))
            Box(Modifier.size(12.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 19.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                subtitle, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
    PlayShuffleRow(tracks)
    TrackList(tracks, "", onAddTo)
}

@Composable
private fun PlaylistList(playlists: List<Playlist>, onOpen: (Playlist) -> Unit, onNew: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Row(
                Modifier.fillMaxWidth().clickable(onClick = onNew).padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.Add, null, tint = MaterialTheme.colorScheme.primary)
                Text("New playlist", color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(start = 14.dp))
            }
        }
        if (playlists.isEmpty()) {
            item {
                Text(
                    "No playlists yet.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        }
        items(playlists, key = { it.id }) { p ->
            Column(
                Modifier.fillMaxWidth().clickable { onOpen(p) }.padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Text(p.name, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    "${p.trackIds.size} song${if (p.trackIds.size == 1) "" else "s"}",
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun PlaylistDetail(
    playlist: Playlist,
    byId: Map<Long, Track>,
    onBack: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit
) {
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    // Keep each row's real position so reorder/remove stay correct if some files have gone missing.
    val rows = playlist.trackIds.mapIndexedNotNull { i, id -> byId[id]?.let { i to it } }
    val playable = rows.map { it.second }

    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 4.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
        Text(playlist.name, Modifier.weight(1f), fontSize = 20.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        IconButton(onClick = onRename) { Icon(Icons.Filled.Edit, "Rename", tint = dim) }
        IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, "Delete playlist", tint = dim) }
    }
    PlayShuffleRow(playable)

    if (rows.isEmpty()) {
        EmptyText("Empty. Use ⋮ on any song and choose Add to playlist.")
    }

    LazyColumn(Modifier.fillMaxSize()) {
        itemsIndexed(rows, key = { _, r -> r.second.id }) { shownIndex, (realIndex, t) ->
            TrackRow(t, onClick = { PlayerHolder.playQueue(playable, shownIndex) }) {
                Row {
                    IconButton(
                        onClick = {
                            rows.getOrNull(shownIndex - 1)?.let { PlaylistStore.move(playlist.id, realIndex, it.first) }
                        },
                        enabled = shownIndex > 0
                    ) {
                        Icon(Icons.Filled.ArrowUpward, "Move up", tint = if (shownIndex > 0) dim else dim.copy(alpha = 0.25f), modifier = Modifier.size(20.dp))
                    }
                    IconButton(
                        onClick = {
                            rows.getOrNull(shownIndex + 1)?.let { PlaylistStore.move(playlist.id, realIndex, it.first) }
                        },
                        enabled = shownIndex < rows.lastIndex
                    ) {
                        Icon(Icons.Filled.ArrowDownward, "Move down", tint = if (shownIndex < rows.lastIndex) dim else dim.copy(alpha = 0.25f), modifier = Modifier.size(20.dp))
                    }
                    IconButton(onClick = { PlaylistStore.removeAt(playlist.id, realIndex) }) {
                        Icon(Icons.Filled.Close, "Remove", tint = dim, modifier = Modifier.size(20.dp))
                    }
                }
            }
        }
    }
}
