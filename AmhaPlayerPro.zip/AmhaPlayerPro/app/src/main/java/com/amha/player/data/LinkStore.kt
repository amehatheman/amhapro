package com.amha.player.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

data class SavedLink(val url: String, val title: String)

/** Recently played links, newest first. Kept on the phone only. */
object LinkStore {
    private const val MAX = 30

    var links by mutableStateOf<List<SavedLink>>(emptyList())
        private set

    private var prefs: SharedPreferences? = null

    fun init(ctx: Context) {
        if (prefs != null) return
        val p = ctx.applicationContext.getSharedPreferences("amha_links", Context.MODE_PRIVATE)
        prefs = p
        links = try {
            val arr = JSONArray(p.getString("links", "[]"))
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                SavedLink(o.getString("url"), o.getString("title"))
            }
        } catch (_: Throwable) {
            emptyList()
        }
    }

    fun add(url: String, title: String) {
        links = (listOf(SavedLink(url, title)) + links.filter { it.url != url }).take(MAX)
        save()
    }

    fun remove(url: String) {
        links = links.filter { it.url != url }
        save()
    }

    fun clear() {
        links = emptyList()
        save()
    }

    private fun save() {
        val arr = JSONArray()
        links.forEach { arr.put(JSONObject().put("url", it.url).put("title", it.title)) }
        prefs?.edit()?.putString("links", arr.toString())?.apply()
    }
}
