package com.amha.player

import android.app.PictureInPictureParams
import android.content.Context
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import com.amha.player.ui.AmhaTheme
import com.amha.player.ui.Accents
import com.amha.player.ui.VideoScreen

/** Video player: Media3 ExoPlayer with custom gesture controls, resume position and PiP. */
class VideoActivity : ComponentActivity() {

    private var player: ExoPlayer? = null
    private lateinit var key: String
    private var inPip by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uriStr = intent.getStringExtra(EXTRA_URI) ?: intent.dataString ?: run { finish(); return }
        val title = intent.getStringExtra(EXTRA_TITLE) ?: guessTitle(uriStr)
        key = "pos_$uriStr"

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        val prefs = getSharedPreferences("amha_resume", Context.MODE_PRIVATE)
        val scheme = Uri.parse(uriStr).scheme?.lowercase()
        val isNetwork = scheme == "http" || scheme == "https" || scheme == "rtsp"
        val builder = ExoPlayer.Builder(this)
        if (isNetwork) {
            val mode = getSharedPreferences("amha", Context.MODE_PRIVATE).getInt("bufferMode", 1)
            builder.setLoadControl(loadControlFor(mode))
        }
        val p = builder.build().also { player = it }
        p.setMediaItem(
            MediaItem.Builder()
                .setUri(Uri.parse(uriStr))
                .setMediaMetadata(MediaMetadata.Builder().setTitle(title).build())
                .build()
        )
        val resumeAt = prefs.getLong(key, 0L)
        if (resumeAt > 0) p.seekTo(resumeAt)
        p.prepare()
        p.playWhenReady = true

        val accent = Accents.load(this)
        setContent {
            AmhaTheme(accent) {
                VideoScreen(
                    activity = this,
                    player = p,
                    title = title,
                    inPip = inPip,
                    onBack = { finish() },
                    onPip = { enterPip() }
                )
            }
        }
    }

    private fun guessTitle(uriStr: String): String {
        val u = Uri.parse(uriStr)
        return u.lastPathSegment?.substringAfterLast('/')?.takeIf { it.isNotBlank() } ?: u.host ?: "Video"
    }

    /** Streaming buffer: 0 small (less data, may stall), 1 normal, 2 large (smoother on weak networks). */
    private fun loadControlFor(mode: Int): DefaultLoadControl {
        val (min, max, start, rebuffer) = when (mode) {
            0 -> listOf(5_000, 15_000, 1_500, 3_000)
            2 -> listOf(30_000, 120_000, 3_000, 6_000)
            else -> listOf(15_000, 50_000, 2_500, 5_000)
        }
        return DefaultLoadControl.Builder().setBufferDurationsMs(min, max, start, rebuffer).build()
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT < 26) return
        val vs = player?.videoSize
        val ratio = if (vs != null && vs.width > 0 && vs.height > 0) {
            val r = vs.width.toFloat() / vs.height
            if (r in 0.42f..2.38f) Rational(vs.width, vs.height) else Rational(16, 9)
        } else Rational(16, 9)
        try {
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(ratio).build())
        } catch (_: Throwable) {
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
    }

    private fun saveProgress() {
        val p = player ?: return
        if (p.isCurrentMediaItemLive) return
        val done = p.duration > 0 && p.currentPosition > p.duration - 5_000
        getSharedPreferences("amha_resume", Context.MODE_PRIVATE).edit()
            .putLong(key, if (done) 0L else p.currentPosition).apply()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (player?.isPlaying == true) enterPip()
    }

    override fun onStop() {
        saveProgress()
        if (!(Build.VERSION.SDK_INT >= 24 && isInPictureInPictureMode)) player?.pause()
        super.onStop()
    }

    override fun onDestroy() {
        saveProgress()
        player?.release()
        player = null
        super.onDestroy()
    }

    companion object {
        const val EXTRA_URI = "uri"
        const val EXTRA_TITLE = "title"
    }
}
