package com.amha.player.data

/** Pure helpers for pasted links. No Android dependencies, so they are easy to test. */
object LinkUtil {
    private val VALID = Regex("""^(https?|rtsp)://[^\s/?#]+[^\s]*$""", RegexOption.IGNORE_CASE)

    /**
     * Cleans what the user pasted. Adds https:// when there is no scheme.
     * Returns null when it is not a link we can play (http, https or rtsp).
     */
    fun normalize(input: String): String? {
        val t = input.trim()
        if (t.isEmpty() || t.any { it.isWhitespace() }) return null
        val withScheme = if (t.contains("://")) t else "https://$t"
        if (!VALID.matches(withScheme)) return null
        // Host must look like something: a dot, localhost, or an IP/port.
        val host = withScheme.substringAfter("://").substringBefore('/').substringBefore('?')
            .substringBefore('#').substringAfterLast('@')
        val hostOnly = host.substringBefore(':')
        if (hostOnly.isEmpty()) return null
        if (!hostOnly.contains('.') && !hostOnly.equals("localhost", true)) return null
        return withScheme
    }

    /** A readable name: the file name in the link, or the site name. */
    fun titleFor(url: String): String {
        val noQuery = url.substringBefore('#').substringBefore('?')
        val afterScheme = noQuery.substringAfter("://")
        val file = afterScheme.substringAfter('/', "").trimEnd('/').substringAfterLast('/')
        if (file.isNotBlank() && file.contains('.')) return decode(file)
        val host = afterScheme.substringBefore('/').substringAfterLast('@').substringBefore(':')
        return host.removePrefix("www.").ifBlank { "Stream" }
    }

    private fun decode(s: String): String =
        try { java.net.URLDecoder.decode(s.replace("+", "%2B"), "UTF-8") } catch (_: Exception) { s }
}
