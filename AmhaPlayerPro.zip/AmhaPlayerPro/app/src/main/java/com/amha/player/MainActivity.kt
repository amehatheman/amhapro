package com.amha.player

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import com.amha.player.ui.AmhaRoot

class MainActivity : ComponentActivity() {

    private var mediaGranted by mutableStateOf(false)
    private var vizGranted by mutableStateOf(false)

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            refreshPermissions()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        refreshPermissions()
        if (!mediaGranted) requestAll()

        setContent {
            AmhaRoot(
                mediaGranted = mediaGranted,
                vizGranted = vizGranted,
                onRequestPermissions = { requestAll() }
            )
        }
    }

    override fun onResume() {
        super.onResume()
        refreshPermissions()
    }

    private fun has(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun refreshPermissions() {
        mediaGranted = if (Build.VERSION.SDK_INT >= 33) {
            has(Manifest.permission.READ_MEDIA_AUDIO) && has(Manifest.permission.READ_MEDIA_VIDEO)
        } else {
            has(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        vizGranted = has(Manifest.permission.RECORD_AUDIO)
    }

    private fun requestAll() {
        val wanted = buildList {
            if (Build.VERSION.SDK_INT >= 33) {
                add(Manifest.permission.READ_MEDIA_AUDIO)
                add(Manifest.permission.READ_MEDIA_VIDEO)
                add(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
            add(Manifest.permission.RECORD_AUDIO)
        }
        permissionLauncher.launch(wanted.toTypedArray())
    }
}
