package com.amha.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.media3.common.TrackGroup
import com.amha.player.data.SubtitleParser

/** One selectable embedded subtitle or audio track. */
data class TrackOption(val label: String, val selected: Boolean, val group: TrackGroup)

@Composable
fun SubtitlePanel(
    subs: SubtitleController,
    textOptions: List<TrackOption>,
    audioOptions: List<TrackOption>,
    onSelectOff: () -> Unit,
    onSelectText: (TrackOption) -> Unit,
    onSelectAudio: (TrackOption) -> Unit,
    onPickFile: () -> Unit,
    onClose: () -> Unit
) {
    val accent = MaterialTheme.colorScheme.primary
    val dim = Color(0xFF9A9AA3)

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .widthIn(max = 460.dp)
                .fillMaxWidth(0.94f)
                .heightIn(max = 340.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Color(0xFF141417))
                .verticalScroll(rememberScrollState())
                .padding(18.dp)
        ) {
            Heading("SUBTITLES", dim)
            ChoiceRow("Off", subs.source == SubSource.OFF, accent) { onSelectOff() }
            textOptions.forEach { o ->
                ChoiceRow(o.label, subs.source == SubSource.EMBEDDED && o.selected, accent) { onSelectText(o) }
            }
            subs.fileName?.let { name ->
                ChoiceRow("File: $name", subs.source == SubSource.EXTERNAL, accent) {
                    if (subs.cues.isNotEmpty()) subs.source = SubSource.EXTERNAL
                }
            }
            Text(
                "Load from file…  (.srt .vtt .ass .ssa)",
                color = accent,
                modifier = Modifier.fillMaxWidth().clickable(onClick = onPickFile).padding(vertical = 12.dp)
            )
            subs.error?.let { Text(it, color = Color(0xFFFF6B6B), fontSize = 12.sp) }

            if (subs.fileName != null) {
                Heading("SYNC (loaded file)", dim, top = 14.dp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { subs.offsetMs -= 1000 }) { Text("−1s", color = accent) }
                    TextButton(onClick = { subs.offsetMs -= 100 }) { Text("−0.1s", color = accent) }
                    Text(
                        "%+.1f s".format(subs.offsetMs / 1000f),
                        modifier = Modifier.weight(1f),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    TextButton(onClick = { subs.offsetMs += 100 }) { Text("+0.1s", color = accent) }
                    TextButton(onClick = { subs.offsetMs += 1000 }) { Text("+1s", color = accent) }
                }
                Text(
                    "Plus means subtitles appear later. Minus means earlier.",
                    color = dim, fontSize = 11.sp
                )
                TextButton(onClick = { subs.offsetMs = 0 }) { Text("Reset delay", color = dim) }

                Heading("ENCODING (loaded file)", dim, top = 8.dp)
                var menu by remember { mutableStateOf(false) }
                Box {
                    Text(
                        SubtitleParser.ENCODINGS[subs.encodingIdx].first + "  ▾",
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF1F1F24))
                            .clickable { menu = true }
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    )
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        SubtitleParser.ENCODINGS.forEachIndexed { i, (label, _) ->
                            DropdownMenuItem(
                                text = { Text(label, color = if (i == subs.encodingIdx) accent else Color.White) },
                                onClick = { subs.setEncoding(i); menu = false }
                            )
                        }
                    }
                }
                Text(
                    "If letters look broken, try another encoding.",
                    color = dim, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp)
                )
            }

            Heading("APPEARANCE", dim, top = 14.dp)
            Text("Size ${SubtitleStyleStore.sizeSp.toInt()}", fontSize = 13.sp)
            Slider(
                value = SubtitleStyleStore.sizeSp,
                onValueChange = { SubtitleStyleStore.setSize(it) },
                valueRange = 12f..40f,
                colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent)
            )
            Text("Height from bottom ${SubtitleStyleStore.bottomPct.toInt()}%", fontSize = 13.sp)
            Slider(
                value = SubtitleStyleStore.bottomPct,
                onValueChange = { SubtitleStyleStore.setBottom(it) },
                valueRange = 0f..40f,
                colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(vertical = 8.dp)) {
                SubtitleStyleStore.colors.forEachIndexed { i, (_, c) ->
                    Box(
                        Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(c)
                            .border(
                                width = if (i == SubtitleStyleStore.colorIdx) 3.dp else 0.dp,
                                color = accent, shape = CircleShape
                            )
                            .clickable { SubtitleStyleStore.setColor(i) }
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SubtitleStyleStore.backgrounds.forEachIndexed { i, label ->
                    val sel = i == SubtitleStyleStore.bgIdx
                    Text(
                        label, fontSize = 13.sp,
                        color = if (sel) Color.Black else Color.White,
                        modifier = Modifier
                            .clip(RoundedCornerShape(18.dp))
                            .background(if (sel) accent else Color(0xFF1F1F24))
                            .clickable { SubtitleStyleStore.setBg(i) }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }

            if (audioOptions.size > 1) {
                Heading("AUDIO TRACK", dim, top = 16.dp)
                audioOptions.forEach { o -> ChoiceRow(o.label, o.selected, accent) { onSelectAudio(o) } }
            }

            TextButton(onClick = onClose, modifier = Modifier.align(Alignment.End).padding(top = 8.dp)) {
                Text("Done", color = accent)
            }
        }
    }
}

@Composable
private fun Heading(text: String, color: Color, top: androidx.compose.ui.unit.Dp = 0.dp) {
    Text(
        text, fontSize = 11.sp, letterSpacing = 2.sp, color = color,
        modifier = Modifier.padding(top = top, bottom = 4.dp)
    )
}

@Composable
private fun ChoiceRow(label: String, selected: Boolean, accent: Color, onClick: () -> Unit) {
    Text(
        (if (selected) "●  " else "○  ") + label,
        color = if (selected) accent else Color.White,
        maxLines = 1,
        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 10.dp)
    )
}
