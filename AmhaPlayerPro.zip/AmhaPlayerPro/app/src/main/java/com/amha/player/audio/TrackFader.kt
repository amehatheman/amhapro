package com.amha.player.audio

import android.content.Context
import androidx.media3.common.C
import androidx.media3.common.Player
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Fades each song out at its end and the next one in at its start (a dip, not an overlap).
 * Only runs while music is playing, and checks slowly except during a fade.
 */
object TrackFader {
    val OPTIONS_SEC = listOf(0, 2, 4, 6, 10)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null
    private var fadeSec = 0
    private lateinit var player: Player

    fun init(ctx: Context, p: Player) {
        if (::player.isInitialized) return
        player = p
        fadeSec = prefIndexToSec(ctx)
        p.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) = restart()
        })
        restart()
    }

    private fun prefIndexToSec(ctx: Context): Int {
        val i = ctx.getSharedPreferences("amha", Context.MODE_PRIVATE).getInt("trackFade", 0)
        return OPTIONS_SEC.getOrElse(i) { 0 }
    }

    fun setIndex(ctx: Context, index: Int) {
        ctx.getSharedPreferences("amha", Context.MODE_PRIVATE).edit().putInt("trackFade", index).apply()
        fadeSec = OPTIONS_SEC.getOrElse(index) { 0 }
        if (fadeSec == 0) EqualizerEngine.setTransitionFade(1f)
        restart()
    }

    private fun restart() {
        job?.cancel()
        job = null
        if (fadeSec == 0 || !::player.isInitialized || !player.isPlaying) return
        job = scope.launch {
            while (true) {
                val fadeMs = fadeSec * 1000L
                val dur = player.duration.takeIf { it != C.TIME_UNSET } ?: -1L
                val pos = player.currentPosition
                EqualizerEngine.setTransitionFade(FadeMath.factor(pos, dur, fadeMs))
                delay(if (FadeMath.fading(pos, dur, fadeMs)) 50L else 400L)
            }
        }
    }
}
