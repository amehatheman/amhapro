package com.amha.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.media3.common.PlaybackParameters
import com.amha.player.audio.SleepTimer
import com.amha.player.playback.PlayerHolder

private val SLEEP_MINUTES = listOf(15, 30, 45, 60, 90, 120)
private val MUSIC_SPEEDS = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)

/** Sleep timer and playback speed for the music player. */
@Composable
fun PlaybackOptionsDialog(onClose: () -> Unit) {
    val accent = MaterialTheme.colorScheme.primary
    val dim = Color(0xFF9A9AA3)
    val player = PlayerHolder.player
    var speed by remember { mutableFloatStateOf(player.playbackParameters.speed) }
    var keepPitch by remember { mutableStateOf(player.playbackParameters.pitch == 1f || speed == 1f) }

    fun applySpeed(s: Float, keep: Boolean) {
        speed = s
        keepPitch = keep
        player.playbackParameters = PlaybackParameters(s, if (keep) 1f else s)
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .widthIn(max = 440.dp)
                .fillMaxWidth(0.94f)
                .heightIn(max = 560.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Color(0xFF141417))
                .verticalScroll(rememberScrollState())
                .padding(18.dp)
        ) {
            Text("SLEEP TIMER", fontSize = 11.sp, letterSpacing = 2.sp, color = dim)
            val label = SleepTimer.label()
            if (label != null) {
                Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(label, color = accent, modifier = Modifier.weight(1f))
                    TextButton(onClick = { SleepTimer.cancel() }) { Text("Cancel timer", color = Color(0xFFFF6B6B)) }
                }
            }
            Chips(SLEEP_MINUTES.take(3).map { "$it min" }, selected = -1, accent) { SleepTimer.start(SLEEP_MINUTES[it]) }
            Chips(SLEEP_MINUTES.drop(3).map { "$it min" }, selected = -1, accent) { SleepTimer.start(SLEEP_MINUTES[it + 3]) }
            Text(
                "End of this song",
                color = if (SleepTimer.endOfTrack) Color.Black else Color.White,
                modifier = Modifier
                    .padding(top = 8.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(if (SleepTimer.endOfTrack) accent else Color(0xFF1F1F24))
                    .clickable { SleepTimer.startEndOfTrack() }
                    .padding(horizontal = 16.dp, vertical = 9.dp),
                fontSize = 13.sp
            )
            Text(
                "Music fades out over the last 15 seconds.",
                color = dim, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp)
            )

            Text("PLAYBACK SPEED", fontSize = 11.sp, letterSpacing = 2.sp, color = dim, modifier = Modifier.padding(top = 20.dp))
            Text(
                "${if (speed % 1f == 0f) speed.toInt().toString() else speed.toString()}x",
                fontSize = 22.sp, modifier = Modifier.padding(top = 4.dp)
            )
            Chips(
                MUSIC_SPEEDS.take(3).map { speedText(it) },
                selected = MUSIC_SPEEDS.take(3).indexOf(speed), accent
            ) { applySpeed(MUSIC_SPEEDS[it], keepPitch) }
            Chips(
                MUSIC_SPEEDS.drop(3).map { speedText(it) },
                selected = MUSIC_SPEEDS.drop(3).indexOf(speed), accent
            ) { applySpeed(MUSIC_SPEEDS[it + 3], keepPitch) }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Keep pitch", fontSize = 15.sp)
                    Text("Off makes it sound like a sped-up or slowed-down record.", fontSize = 11.sp, color = dim)
                }
                Switch(
                    checked = keepPitch,
                    onCheckedChange = { applySpeed(speed, it) },
                    colors = SwitchDefaults.colors(checkedThumbColor = Color.Black, checkedTrackColor = accent)
                )
            }

            TextButton(onClick = onClose, modifier = Modifier.align(Alignment.End).padding(top = 8.dp)) {
                Text("Done", color = accent)
            }
        }
    }
}

private fun speedText(s: Float) = (if (s % 1f == 0f) s.toInt().toString() else s.toString()) + "x"

@Composable
private fun Chips(labels: List<String>, selected: Int, accent: Color, onPick: (Int) -> Unit) {
    Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        labels.forEachIndexed { i, l ->
            val sel = i == selected
            Text(
                l, fontSize = 13.sp,
                color = if (sel) Color.Black else Color.White,
                modifier = Modifier
                    .clip(RoundedCornerShape(18.dp))
                    .background(if (sel) accent else Color(0xFF1F1F24))
                    .clickable { onPick(i) }
                    .padding(horizontal = 16.dp, vertical = 9.dp)
            )
        }
    }
}
