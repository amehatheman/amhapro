package com.amha.player.ui

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import com.amha.player.data.Cue
import com.amha.player.data.SubtitleParser

/** User's subtitle look. Saved on the phone, shared by loaded files and embedded subtitles. */
object SubtitleStyleStore {
    val colors: List<Pair<String, Color>> = listOf(
        "White" to Color.White,
        "Yellow" to Color(0xFFFFE14D),
        "Cyan" to Color(0xFF4DE1FF),
        "Green" to Color(0xFF7CFF8A)
    )
    val backgrounds = listOf("Shadow", "Box", "Plain")

    var sizeSp by mutableFloatStateOf(20f)
        private set
    var colorIdx by mutableIntStateOf(0)
        private set
    var bgIdx by mutableIntStateOf(0)
        private set
    var bottomPct by mutableFloatStateOf(6f) // 0..40 % of screen height
        private set

    private var prefs: SharedPreferences? = null

    fun init(ctx: Context) {
        if (prefs != null) return
        val p = ctx.applicationContext.getSharedPreferences("amha_sub", Context.MODE_PRIVATE)
        prefs = p
        sizeSp = p.getFloat("size", 20f)
        colorIdx = p.getInt("color", 0).coerceIn(colors.indices)
        bgIdx = p.getInt("bg", 0).coerceIn(backgrounds.indices)
        bottomPct = p.getFloat("bottom", 6f)
    }

    fun setSize(v: Float) { sizeSp = v.coerceIn(12f, 40f); save() }
    fun setColor(i: Int) { colorIdx = i.coerceIn(colors.indices); save() }
    fun setBg(i: Int) { bgIdx = i.coerceIn(backgrounds.indices); save() }
    fun setBottom(v: Float) { bottomPct = v.coerceIn(0f, 40f); save() }

    private fun save() {
        prefs?.edit()
            ?.putFloat("size", sizeSp)?.putInt("color", colorIdx)
            ?.putInt("bg", bgIdx)?.putFloat("bottom", bottomPct)?.apply()
    }
}

enum class SubSource { OFF, EMBEDDED, EXTERNAL }

/** Per-video subtitle state: a loaded file with delay and encoding, or embedded track mode. */
class SubtitleController {
    var source by mutableStateOf(SubSource.OFF)
    var fileName by mutableStateOf<String?>(null)
        private set
    var encodingIdx by mutableIntStateOf(0)
        private set
    var offsetMs by mutableLongStateOf(0L)
    var cues by mutableStateOf<List<Cue>>(emptyList())
        private set
    var error by mutableStateOf<String?>(null)
        private set

    private var bytes: ByteArray? = null

    fun load(name: String, data: ByteArray) {
        bytes = data
        fileName = name
        offsetMs = 0L
        reparse()
        if (cues.isNotEmpty()) source = SubSource.EXTERNAL
    }

    fun setEncoding(i: Int) {
        encodingIdx = i.coerceIn(SubtitleParser.ENCODINGS.indices)
        reparse()
    }

    private fun reparse() {
        val b = bytes ?: return
        try {
            val text = SubtitleParser.decode(b, SubtitleParser.ENCODINGS[encodingIdx].second)
            cues = SubtitleParser.parse(text)
            error = if (cues.isEmpty()) "No subtitles found. Wrong encoding or unsupported file?" else null
        } catch (t: Throwable) {
            cues = emptyList()
            error = "Could not read this file."
        }
    }

    /** Text to show at the given playback position, honouring the delay. */
    fun textAt(posMs: Long): String? {
        val list = cues
        if (list.isEmpty()) return null
        val t = posMs - offsetMs
        // binary search: last cue whose start <= t
        var lo = 0
        var hi = list.lastIndex
        var found = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (list[mid].startMs <= t) { found = mid; lo = mid + 1 } else hi = mid - 1
        }
        if (found < 0) return null
        val active = ArrayList<String>(2)
        var i = found
        while (i >= 0 && i > found - 6) {
            val c = list[i]
            if (t < c.endMs) active.add(0, c.text)
            i--
        }
        return if (active.isEmpty()) null else active.joinToString("\n")
    }
}
